import { createAsyncThunk, createSlice, PayloadAction } from "@reduxjs/toolkit";
import { MarketChart } from "../config/api";
import { IChartApi } from "../types/Currency";

interface chartState {
  chartData: IChartApi;
  days: number;
  status: string | null;
  error: string | null | undefined;
}

export const fetchApiChart = createAsyncThunk<
  IChartApi,
  number,
  { rejectValue: string }
>("chart/fetchApiChart", async (action, { rejectWithValue }) => {
  try {
    const response = await fetch(MarketChart("bitcoin", "usd", action));

    if (!response.ok) {
      throw new Error("Server Error!");
    }

    const data = await response.json();

    return data;
  } catch (error: any) {
    return rejectWithValue(error.message);
  }
});

const initialState: chartState = {
  chartData: { prices: [[]], market_caps: [[]], total_volumes: [[]] },
  days: 10,
  status: null,
  error: null,
};

export const chartSlice = createSlice({
  name: "chart",
  initialState,
  reducers: {
    setDays(state, action: PayloadAction<number>) {
      state.days = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(fetchApiChart.pending, (state) => {
      state.status = "loading";
      state.error = null;
    });
    builder.addCase(fetchApiChart.fulfilled, (state, action) => {
      state.status = "resolved";
      state.chartData = action.payload;
    });
    builder.addCase(fetchApiChart.rejected, (state, action) => {
      state.status = "rejected";
      state.error = action.payload;
    });
  },
});

export const { setDays } = chartSlice.actions;

export default chartSlice.reducer;
