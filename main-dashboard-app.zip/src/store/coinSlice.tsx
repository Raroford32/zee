import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { MarketCoins } from "../config/api";
import { ICoinGeckoMarket } from "../types/Currency";

interface CoinsState {
  coin: ICoinGeckoMarket[];
  status: string | null;
  error: string | null | undefined;
}

export const fetchCoin = createAsyncThunk<
  ICoinGeckoMarket[],
  void,
  { rejectValue: string }
>("coins/fetchCoin", async (_, { rejectWithValue }) => {
  try {
    const response = await fetch(MarketCoins(["zeedex"]));

    if (!response.ok) {
      throw new Error("Server Error!");
    }

    const data: ICoinGeckoMarket[] = await response.json();

    return data;
  } catch (error: any) {
    return rejectWithValue(error.message);
  }
});

const initialState: CoinsState = {
  coin: [],
  status: null,
  error: null,
};

export const coinsSlice = createSlice({
  name: "coins",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(fetchCoin.pending, (state) => {
      state.status = "loading";
      state.error = null;
    });
    builder.addCase(fetchCoin.fulfilled, (state, action) => {
      state.status = "resolved";
      state.coin = action.payload;
    });
    builder.addCase(fetchCoin.rejected, (state, action) => {
      state.status = "rejected";
      state.error = action.payload;
    });
  },
});

export default coinsSlice.reducer;
