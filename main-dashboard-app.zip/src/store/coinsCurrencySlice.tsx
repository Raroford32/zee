import { createAsyncThunk, createSlice, PayloadAction } from "@reduxjs/toolkit";
import { ICoinGeckoMarket } from "../types/Currency";
import { TrendingCoins } from "../config/api";

interface CoinsState {
  coins: ICoinGeckoMarket[];
  currency: string;
  status: string | null;
  error: string | null | undefined;
}

interface Currency {
  currency: string;
}

export const fetchCurrencyTopListCoins = createAsyncThunk<
  ICoinGeckoMarket[],
  Currency,
  { rejectValue: string }
>("coins/fetchCurrencyTopListCoins", async (currency, { rejectWithValue }) => {
  try {
    const response = await fetch(TrendingCoins(currency.currency));

    if (!response.ok) {
      throw new Error("Server Error!");
    }

    const data: ICoinGeckoMarket[] = await response.json();

    return data;
  } catch (error: any) {
    return rejectWithValue(error.message);
  }
});

const initialState: CoinsState = {
  coins: [],
  currency: "usd",
  status: null,
  error: null,
};

export const coinsSlice = createSlice({
  name: "coins",
  initialState,
  reducers: {
    setCurrency(state, action: PayloadAction<string>) {
      state.currency = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(fetchCurrencyTopListCoins.pending, (state) => {
      state.status = "loading";
      state.error = null;
    });
    builder.addCase(fetchCurrencyTopListCoins.fulfilled, (state, action) => {
      state.status = "resolved";
      state.coins = action.payload;
    });
    builder.addCase(fetchCurrencyTopListCoins.rejected, (state, action) => {
      state.status = "rejected";
      state.error = action.payload;
    });
  },
});

export const { setCurrency } = coinsSlice.actions;

export default coinsSlice.reducer;
