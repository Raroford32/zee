import { configureStore } from "@reduxjs/toolkit";
import { TypedUseSelectorHook, useDispatch, useSelector } from "react-redux";
import coinsCurrencyReducer from "./coinsCurrencySlice";
import coinCurrencyReducer from "./coinCurrencySlice";
import coinsReducer from "./coinsSlice";
import coinReducer from "./coinSlice";
import chartApi from "./chartApiSlice";

const store = configureStore({
  reducer: {
    coinsCurrency: coinsCurrencyReducer,
    coinCurrency: coinCurrencyReducer,
    coins: coinsReducer,
    coin: coinReducer,
    chart: chartApi,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector;
export const useAppDispatch: () => AppDispatch = useDispatch;

export default store;
