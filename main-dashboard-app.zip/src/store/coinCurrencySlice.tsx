import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { MarketCoins } from "../config/api";
import { ICoinGeckoMarket } from "../types/Currency";

interface CoinsState {
  coin: ICoinGeckoMarket[];
  status: string | null;
  error: string | null | undefined;
}

interface Currency {
  ids: string[];
  currency: string;
}

export const fetchCurrencyCoin = createAsyncThunk<
  ICoinGeckoMarket[],
  Currency,
  { rejectValue: string }
>("coins/fetchCurrencyCoin", async (currency, { rejectWithValue }) => {
  try {
    const response = await fetch(MarketCoins(currency.ids, currency.currency));

    if (!response.ok) {
      throw new Error("Server Error!");
    }

    const data: ICoinGeckoMarket[] = await response.json();

    return data;
  } catch (error: any) {
    return rejectWithValue(error.message);
  }
});

const initialState: CoinsState = {
  coin: [],
  status: null,
  error: null,
};

export const coinsSlice = createSlice({
  name: "coins",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(fetchCurrencyCoin.pending, (state) => {
      state.status = "loading";
      state.error = null;
    });
    builder.addCase(fetchCurrencyCoin.fulfilled, (state, action) => {
      state.status = "resolved";
      state.coin = action.payload;
    });
    builder.addCase(fetchCurrencyCoin.rejected, (state, action) => {
      state.status = "rejected";
      state.error = action.payload;
    });
  },
});

export default coinsSlice.reducer;
