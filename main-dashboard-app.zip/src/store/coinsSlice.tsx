import { createAsyncThunk, createSlice, PayloadAction } from "@reduxjs/toolkit";
import { TrendingCoins } from "../config/api";
import { ICoinGeckoMarket } from "../types/Currency";

interface CoinsState {
  coins: ICoinGeckoMarket[];
  currencyFrom: string;
  currencyTo: string;
  status: string | null;
  error: string | null | undefined;
}

export const fetchTopListCoins = createAsyncThunk<
  ICoinGeckoMarket[],
  void,
  { rejectValue: string }
>("coins/fetchTopListCoins", async (_, { rejectWithValue }) => {
  try {
    const response = await fetch(TrendingCoins("usd"));

    if (!response.ok) {
      throw new Error("Server Error!");
    }

    const data: ICoinGeckoMarket[] = await response.json();

    return data;
  } catch (error: any) {
    return rejectWithValue(error.message);
  }
});

const initialState: CoinsState = {
  coins: [],
  currencyFrom: "btc",
  currencyTo: "btc",
  status: null,
  error: null,
};

export const coinsSlice = createSlice({
  name: "coins",
  initialState,
  reducers: {
    setCurrencyFrom(state, action: PayloadAction<string>) {
      state.currencyFrom = action.payload;
    },
    setCurrencyTo(state, action: PayloadAction<string>) {
      state.currencyTo = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(fetchTopListCoins.pending, (state) => {
      state.status = "loading";
      state.error = null;
    });
    builder.addCase(fetchTopListCoins.fulfilled, (state, action) => {
      state.status = "resolved";
      state.coins = action.payload;
    });
    builder.addCase(fetchTopListCoins.rejected, (state, action) => {
      state.status = "rejected";
      state.error = action.payload;
    });
  },
});

export const { setCurrencyFrom, setCurrencyTo } = coinsSlice.actions;

export default coinsSlice.reducer;
