import { FC, memo, useState } from 'react';

import notificationBellBlack from '../../assets/icons/notificationBellBlack.svg';
import { Button } from '../../components/Button';
import { LiquidityPoolsTable } from './components/LiquidityPoolsTable';
import classNames from 'classnames';
import search from '../../assets/icons/search.svg';
import graySmallArrow from '../../assets/icons/graySmallArrow.svg';

const tableData = [
  {
    days: 1,
    label: '1D'
  },
  {
    days: 4,
    label: '1W'
  },
  {
    days: 24,
    label: '1M'
  },
  {
    days: 168,
    label: '3M'
  },
  {
    days: 720,
    label: '1Y'
  },
  {
    days: 3600,
    label: 'YTD'
  },
  {
    days: 3601,
    label: 'ALL'
  }
];

export const Liquidity: FC = memo(() => {
  const [tableDataFilter, setTableDataFilter] = useState(tableData[2].days);
  return (
    <div className="container px-4 my-7.5 sm:px-0">
      <div className="border-y border-dark-300 flex flex-wrap py-1.5 justify-between gap-2 items-center">
        <h1 className="text-xl font-medium">Liquidity Pools</h1>

        <div className="text-sm">
          <span className="text-light-500">TVL:</span> $62,640,428.1
        </div>

        <div className="text-sp">
          Here you can view tokens that are currently trending on Coingecko and Coinmarketcap
        </div>

        <div className="flex gap-7.5 items-center">
          <div className="flex flex-col text-[7px]">
            Tired of missing out on tokens that could be Trending Soon?
            <span className="font-medium">Subscribe now to receive email notifications!</span>
          </div>

          <Button height={24}>
            <div className="flex gap-1.25 items-center">
              <img src={notificationBellBlack} alt="notificationBellBlack" /> Subscribe
            </div>
          </Button>
        </div>
      </div>

      <div className="mt-7.5">
        <LiquidityPoolsTable />
      </div>

      <div className="py-7.5 flex justify-center sm:justify-between gap-4 items-center flex-wrap">
        <div className="flex gap-2.5 items-center font-medium">
          <span className="text-xs decoration-dashed underline">Timeframe</span>

          <div className="flex text-sp">
            {tableData.map(({ days, label }, i) => (
              <div
                key={i}
                onClick={() => setTableDataFilter(days)}
                className={classNames(
                  'rounded flex text-light-300 hover:bg-dark-100 items-center cursor-pointer justify-center h-5 px-1',
                  {
                    'gradient !text-dark-900': tableDataFilter === days
                  }
                )}>
                {label}
              </div>
            ))}
          </div>
        </div>

        <div className="flex gap-3.5 text-light-500">
          <div className="h-6 rounded-full bg-dark-300 text-sp px-4 flex items-center gap-2">
          All Chains

          <img src={graySmallArrow} alt="graySmallArrow" />
          </div>

          <label className="h-6 rounded-full bg-dark-300 text-sp px-4 flex items-center gap-2">
            <input
              type="text"
              placeholder="Search by token name or tag"
              className="placeholder:text-light-500 bg-transparent focus:outline-none"></input>

            <img src={search} alt="search" className="h-2.5" />
          </label>
        </div>
      </div>
    </div>
  );
});
