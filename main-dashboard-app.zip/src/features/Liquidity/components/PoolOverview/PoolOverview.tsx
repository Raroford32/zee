import { FC, memo, useEffect, useState } from "react";
import { SwapChart } from "../../../Swap/components/SwapChart";
import classNames from "classnames";
import { Tab } from "@headlessui/react";
import ETH from "../../../../assets/icons/cryptocurrenciesIcons/ETH.svg";
import BNB from "../../../../assets/icons/cryptocurrenciesIcons/BNB.svg";
import { useAppSelector } from "../../../../store";
import { ChartDataItem } from "../../../../types/Currency";

const chartData = [
  {
    days: 1,
    label: "1H",
  },
  {
    days: 4,
    label: "4H",
  },
  {
    days: 24,
    label: "1D",
  },
  {
    days: 168,
    label: "1W",
  },
  {
    days: 720,
    label: "1M",
  },
  {
    days: 3600,
    label: "6M",
  },
];

export const PoolOverview: FC = memo(() => {
  const { chartData: dataChart } = useAppSelector((state) => state.chart);

  const [currChartData, setCurrChartData] = useState<ChartDataItem[]>([]);
  const [chartDataFilter, setChartDataFilter] = useState(chartData[2].days);

  useEffect(() => {
    if (dataChart.prices.length > 1) {
      setCurrChartData(
        dataChart.prices.map((item: number[]) => ({
          time: item[0] / 1000,
          value: item[1],
          open: item[1],
          high: item[1],
          low: 0,
          close: 0,
        }))
      );
    }

    // eslint-disable-next-line
  }, [chartDataFilter, dataChart]);

  return (
    <div>
      <div className="text-xl font-medium">Classic Pool</div>

      <div className="text-light-500 mt-2 text-sp">
        Contract 0x8De382...D7851d
      </div>

      <div className="flex flex-col sm:flex-row gap-7.5 mt-7.5">
        <div className="flex flex-col gap-7.5">
          <div className="card min-w-[220px] px-5 pt-3.25 pb-2.5 text-sp">
            <div className="flex gap-2 pb-2 border-b border-primaryBorder font-medium">
              <img src={ETH} alt="ETH" className="w-4" />
              1 ETH =
              <img src={BNB} alt="BNB" className="w-4" />
              5.846 cBNB
            </div>

            <div className="mt-2 text-light-500">Assets in Pool</div>

            <div className="flex justify-between mt-2.5">
              <div className="text-cyan">50%</div>

              <div className="flex gap-2 items-center">
                <img src={ETH} alt="ETH" className="w-4" />
                38.992 ETH
              </div>
            </div>

            <div className="flex justify-between mt-2.5">
              <div className="text-cyan">50%</div>

              <div className="flex gap-2 items-center">
                <img src={BNB} alt="BNB" className="w-4" />
                227.99 cBNB
              </div>
            </div>
          </div>

          <div className="card min-w-[220px] p-2.5 text-xs text-light-500 flex flex-col gap-3.25">
            <div className="py-2 px-2.5 bg-dark-900 rounded flex items-center justify-between">
              TVL <span className="text-cyan">$145,466.27</span>
            </div>

            <div className="py-2 px-2.5 bg-dark-900 rounded flex items-center justify-between">
              Volume (24h) <span>$0</span>
            </div>

            <div className="py-2 px-2.5 bg-dark-900 rounded flex items-center justify-between">
              APR (24h) <span className="text-cyan">33.8%</span>
            </div>

            <div className="py-2 px-2.5 bg-dark-900 rounded flex items-center justify-between">
              Swap Fee <br /> (ETH to cBNB) 🛈{" "}
              <span className="text-cyan">0.20%</span>
            </div>

            <div className="py-2 px-2.5 bg-dark-900 rounded flex items-center justify-between">
              Swap Fee <br />
              (cBNB to ETH) 🛈 <span className="text-cyan">0.20%</span>
            </div>

            <div className="py-2 px-2.5 bg-dark-900 rounded flex items-center justify-between">
              LP Dividends 🛈 <span className="text-cyan">50.00%</span>
            </div>
          </div>
        </div>

        <div className="grow card overflow-hidden">
          <div className="flex flex-col min-h-full justify-center">
            <div className="mb-6 flex py-4 text-sm text-light-300 items-end sm:items-center">
              <div className="w-[82px] text-center text-xl">$</div>

              <div className="grow flex justify-between flex-col lg:flex-row mx-7.5 items-center gap-2">
                <div className="flex flex-col gap-4">
                  <div className="flex">
                    <Tab.Group>
                      <Tab.List className="h-9 bg-dark-900 rounded p-1 text-light-500 flex gap-2">
                        <Tab
                          className={({ selected }) =>
                            classNames("px-1.25 h-full rounded", {
                              "bg-cyan text-black": selected,
                              "hover:bg-dark-100": !selected,
                            })
                          }
                        >
                          Liquidity
                        </Tab>
                        <Tab
                          className={({ selected }) =>
                            classNames("px-1.25 h-full rounded", {
                              "bg-cyan text-black": selected,
                              "hover:bg-dark-100": !selected,
                            })
                          }
                        >
                          Volume
                        </Tab>
                        <Tab
                          className={({ selected }) =>
                            classNames("px-1.25 h-full rounded font-medium", {
                              "bg-cyan text-black": selected,
                              "hover:bg-dark-100": !selected,
                            })
                          }
                        >
                          ETH/GET
                        </Tab>
                        <Tab
                          className={({ selected }) =>
                            classNames("px-1.25 h-full rounded font-medium", {
                              "bg-cyan text-black": selected,
                              "hover:bg-dark-100": !selected,
                            })
                          }
                        >
                          GET/ETH
                        </Tab>
                      </Tab.List>
                    </Tab.Group>
                  </div>

                  <div className="rounded-lg bg-dark-900 flex items-center p-2.5">
                    <div className="text-base font-medium pr-5 border-r border-primaryBorder">
                      607.07 USDT
                    </div>
                    <div className="pl-5 text-light-500">Past 24 hours</div>
                    <div className="text-cyan ml-3.25">4.86%</div>
                  </div>
                </div>

                <div className="rounded-lg bg-dark-900 flex h-[50px] p-1.25 mt-2 text-xl">
                  {chartData.map(({ days, label }, i) => (
                    <div
                      key={i}
                      onClick={() => setChartDataFilter(days)}
                      className={classNames(
                        "rounded-md flex items-center cursor-pointer hover:bg-dark-300 justify-center p-1.5",
                        {
                          "gradient text-dark-900": chartDataFilter === days,
                        }
                      )}
                    >
                      {label}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="relative">
              <SwapChart data={currChartData} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
});
