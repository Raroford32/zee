import { FC, memo } from 'react';

import { Chart as ChartJS, registerables, ChartOptions } from 'chart.js';
import { Bar } from 'react-chartjs-2';

ChartJS.register(...registerables);

const dataForDataset = [2, 4.1, 5.3, 6.6, 7.38, 6.1, 5.6, 4.4, 3, 2];

const options: ChartOptions<'bar'> = {
  maintainAspectRatio: false,
  plugins: {
    tooltip: {
      enabled: false // <-- this option disables tooltips
    },
    legend: {
      display: false
    }
  },
  layout: {
    padding: -20
  },
  scales: {
    x: {
      grid: {
        display: false
      },
      stacked: true,
      ticks: {
        display: false
      }
    },
    y: {
      grid: {
        display: false
      },
      max: 8,
      ticks: {
        padding: 29,
        callback: (value) => {
          if (value === 2) {
            return (+value).toFixed(2);
          }

          if (value === 4) {
            return (+value).toFixed(2);
          }

          if (value === 7) {
            return (+value).toFixed(2);
          }
        },
        color: '#505050',
        font: {
          size: 10,
          family: 'Ubuntu'
        }
      }
    }
  }
};

export const MyLiquidityChart: FC = memo(() => {
  const data = {
    labels: dataForDataset,
    datasets: [
      {
        order: 2,
        label: 'Dataset 1',
        data: dataForDataset,
        borderRadius: 5,
        barPercentage: 0.9,
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        backgroundColor: (context: any) => {
          const bgColorGreen = '#23F4A9';
          // const bgColorBlue = 'rgba(10, 183, 238, 0.96)';

          const bgColor3 = 'rgba(21, 21, 21, 0.00)';

          if (!context.chart.chartArea) {
            return;
          }

          const {
            ctx,
            chartArea: { top, bottom }
          } = context.chart;

          const gradientBg = ctx.createLinearGradient(0, top, 0, bottom);
          gradientBg.addColorStop(0, bgColorGreen);
          // gradientBg.addColorStop(0.5, bgColor2);
          gradientBg.addColorStop(1, bgColor3);

          return gradientBg;
        }
      }
    ]
  };

  return <Bar options={options} data={data} />;
});
