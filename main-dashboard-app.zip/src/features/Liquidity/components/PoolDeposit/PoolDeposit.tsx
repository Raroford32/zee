import { FC, memo } from 'react';

import ETH from '../../../../assets/icons/cryptocurrenciesIcons/ETH.svg';
import DOGE from '../../../../assets/icons/cryptocurrenciesIcons/DOGE.svg';
import { Button } from '../../../../components/Button';

import { DepositSlider } from './DepositSlider';
import { MyLiquidityChart } from './MyLiquidityChart';
import { TokensToDeposit } from './TokensToDeposit';

export const PoolDeposit: FC = memo(() => {
  return (
    <div className="flex flex-col 2xl:flex-row gap-7.5 ">
      <div>
        <div className="text-xl font-medium">Deposit</div>

        <div className="text-light-500 mt-2 text-sp">
          Deposit tokens to the pool to start earning trading fees
        </div>

        <div className="flex gap-7.5 flex-wrap mt-7.5 justify-center lg:justify-normal">
          <TokensToDeposit />

          <div className="flex flex-row sm:flex-col gap-1 md:gap-7.5">
            <DepositSlider />

            <div className="card min-w-[180px] p-5 text-xs font-medium flex-1">
              <div className="text-sp">Price</div>

              <div className="flex gap-2 mt-7.5">
                <img src={ETH} alt="ETH" className="w-4" />1 ETH = 5.845 DOGE
              </div>

              <div className="flex gap-2 mt-5">
                <img src={DOGE} alt="DOGE" className="w-4" />1 DOGE = 0.171ETH
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grow flex flex-col">
        <div className="text-xl font-medium">My Liquidity</div>

        <div className="flex flex-col gap-7.5 mt-[53px] h-full">
          <div className="card grow">
            <MyLiquidityChart />
          </div>

          <div className="flex gap-7.5 flex-col sm:flex-row">
            <div className="card grow min-h-[96px] flex items-center justify-center text-sp">
              <div className="text-cyan">%</div>
              <div className="ml-1.5">My pool share</div>
              <div className="text-light-500 ml-5">0%</div>
            </div>

            <div className="card grow flex justify-between px-5 py-2.5 sm:py-0 items-center flex-col gap-2 sm:flex-row">
              <div>
                <div className="text-sp">Deposite Balance</div>

                <div className="flex gap-5 mt-2">
                  <div className="flex gap-2 items-center">
                    <img src={ETH} alt="ETH" className="w-4 h-4" />

                    <div className="">
                      <div className="text-xs">2.08685</div>
                      <div className="text-light-500 text-smaller">SWIP USD</div>
                    </div>
                  </div>

                  <div className="flex gap-2 items-center">
                    <img src={DOGE} alt="DOGE" className="w-4 h-4" />

                    <div className="">
                      <div className="text-xs">18.2693</div>
                      <div className="text-light-500 text-smaller">SWIP USD</div>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <div className="text-sp">Claimable Fees</div>

                <div className="flex gap-2 mt-2 items-center">
                  <div className="flex gap-2 items-center">
                    <img src={ETH} alt="ETH" className="w-4 h-4" />

                    <div className="">
                      <div className="text-xs">0</div>
                      <div className="text-light-500 text-smaller">SWIP USD</div>
                    </div>
                  </div>

                  <span className="text-smaller text-light-500">+</span>

                  <div className="flex gap-2 items-center">
                    <img src={DOGE} alt="DOGE" className="w-4 h-4" />

                    <div className="">
                      <div className="text-xs">0</div>
                      <div className="text-light-500 text-smaller">SWIP USD</div>
                    </div>
                  </div>

                  <Button height={20} width={111} className="!text-sp ml-5">
                    Claim Fees
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
});
