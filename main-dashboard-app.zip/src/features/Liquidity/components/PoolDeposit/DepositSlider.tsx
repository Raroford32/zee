import { Tab } from '@headlessui/react';
import classNames from 'classnames';
import { FC, memo } from 'react';

export const DepositSlider: FC = memo(() => {
  return (
    <div className="card w-[180px] p-5 flex flex-col justify-between">
      <Tab.Group>
        <Tab.Panels>
          <Tab.Panel>
            <div className="text-sp text-cyan">1/4</div>

            <div className="text-xs mt-2.5">Put your assets to work</div>

            <div className="text-light-500 text-s mt-1">
              Deposit tokens to provide liquidity for traders. You will receive LP tokens
              representing pool share.
            </div>
          </Tab.Panel>

          <Tab.Panel>
            <div className="text-sp text-cyan">2/4</div>

            <div className="text-xs mt-2.5">Earn from every trade</div>

            <div className="text-light-500 text-s mt-1">
              Earn trading fees like professional market makers. Earned fees are auto compounded in
              position.
            </div>
          </Tab.Panel>

          <Tab.Panel>
            <div className="text-sp text-cyan">3/4</div>

            <div className="text-xs mt-2.5">Manage your position</div>

            <div className="text-light-500 text-s mt-1">
              Adjust, increase or decrease your position anytime by deposit or withdrawal.
            </div>
          </Tab.Panel>

          <Tab.Panel>
            <div className="text-sp text-cyan">4/4</div>

            <div className="text-xs mt-2.5">Funds are always avaible</div>

            <div className="text-light-500 text-s mt-1">
              Withdraw to receive pool tokens whenever you want. Earned fees are already included.
            </div>
          </Tab.Panel>
        </Tab.Panels>

        <Tab.List className="flex justify-between gap-3.5 mt-auto">
          <Tab className="pt-2 flex-1">
            {({ selected }) => (
              <div
                className={classNames('bg-dark-900 rounded-full h-0.5', {
                  '!bg-cyan': selected
                })}></div>
            )}
          </Tab>
          <Tab className="pt-2 flex-1">
            {({ selected }) => (
              <div
                className={classNames('bg-dark-900 rounded-full h-0.5', {
                  '!bg-cyan': selected
                })}></div>
            )}
          </Tab>
          <Tab className="pt-2 flex-1">
            {({ selected }) => (
              <div
                className={classNames('bg-dark-900 rounded-full h-0.5', {
                  '!bg-cyan': selected
                })}></div>
            )}
          </Tab>
          <Tab className="pt-2 flex-1">
            {({ selected }) => (
              <div
                className={classNames('bg-dark-900 rounded-full h-0.5', {
                  '!bg-cyan': selected
                })}></div>
            )}
          </Tab>
        </Tab.List>
      </Tab.Group>
    </div>
  );
});
