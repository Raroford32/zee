import { FC, memo } from 'react';
import { Button } from '../../../../components/Button';
import { SwitchItem } from '../../../../components/SwitchItem';
import settingsWhite from '../../../../assets/icons/settingsWhite.svg';
import ETH from '../../../../assets/icons/cryptocurrenciesIcons/ETH.svg';
import DOGE from '../../../../assets/icons/cryptocurrenciesIcons/DOGE.svg';

export const TokensToDeposit: FC = memo(() => {
  return (
    <div className="card p-5 pt-3 min-w-[339px] grow lg:grow-0">
      <div className="flex justify-between text-sp">
        Tokens to deposit
        <img src={settingsWhite} alt="settingsWhite" />
      </div>

      <div className="mt-5 flex justify-between">
        <div className="flex gap-2 font-medium text-xs">
          <img src={ETH} alt="ETH" className="w-4" />
          ETH
        </div>

        <div className="text-s flex gap-2.5 text-light-500 items-center">
          Balance: 0
          <Button width={34} height={13} className="!text-s rounded-sm">
            Max
          </Button>
        </div>
      </div>

      <div className="bg-dark-500 rounded px-2.5 py-3 flex items-center mt-2.5">
        <input
          type="text"
          className="bg-transparent text-xs placeholder:text-light-500 focus:outline-none font-medium"
          placeholder="0.0"
        />
      </div>

      <div className="mt-5 flex justify-between">
        <div className="flex gap-2 font-medium text-xs">
          <img src={DOGE} alt="DOGE" className="w-4" />
          DOGE
        </div>

        <div className="text-s flex gap-2.5 text-light-500 items-center">
          Balance: 0
          <Button width={34} height={13} className="!text-s rounded-sm">
            Max
          </Button>
        </div>
      </div>

      <div className="bg-dark-500 rounded px-2.5 py-3 flex items-center mt-2.5">
        <input
          type="text"
          className="bg-transparent text-xs placeholder:text-light-500 focus:outline-none font-medium"
          placeholder="0.0"
        />
      </div>

      <div className="mt-5 flex gap-2.5 text-sp text-light-500">
        <SwitchItem /> Add tokens in balanced proportion 🛈
      </div>

      <Button isFull height={32} className="mt-5">
        Please enter amounts
      </Button>
    </div>
  );
})
