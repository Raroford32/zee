import { FC, memo, useState } from 'react';

import folder from '../../../../assets/icons/folder.svg';
import { Button } from '../../../../components/Button';
import DOGE from '../../../../assets/icons/cryptocurrenciesIcons/DOGE.svg';
import USDC from '../../../../assets/icons/cryptocurrenciesIcons/USDC.svg';

export const PoolPositions: FC = memo(() => {
  const [isDeposit, setIsDeposit] = useState(false);
  return (
    <div>
      <div className="text-xl font-medium mb-5">My Positions</div>

      {isDeposit ? (
        <div className="card w-full sm:w-[270px] px-2.5 pb-2.5 pt-5">
          <div className="text-sp">Your Positions (1)</div>

          <div className="flex text-xs font-medium mt-4.5">
            <img src={DOGE} alt="DOGE" className="h-4" />
            <img src={USDC} alt="USDC" className="w-4 -translate-x-1/2" />
            DOGE / USDC
          </div>

          <div className="text-sp mt-1 text-light-500">
            DAI: <span className="text-white">152.23351</span> USDC: 1366.86004
          </div>

          <div className="flex gap-1 mt-3.25">
            <Button height={20} className="flex-1 !text-smaller">
              Increase Liquidity
            </Button>
            <Button height={20} className="flex-1 !text-smaller from-[#E84142] to-[#7AE5B5]">
              Remove Liquidity
            </Button>
          </div>

          <div className="flex justify-between text-sp p-2.5 bg-dark-900 rounded mt-4">
            Liquidity APR 🛈
            <span>12.68%</span>
          </div>

          <div className="flex justify-between text-sp p-2.5 bg-dark-900 rounded mt-4 items-center">
            Gains
            <div>
              -$1.17
              <div className="text-light-500 text-s mt-1.5 text-end">-0.01%</div>
            </div>
          </div>

          <div className="flex justify-between text-sp p-2.5 mb-5 bg-dark-900 rounded mt-4 items-center">
            Market Value
            <div>
              $2,059.34
              <div className="text-light-500 text-s mt-1.5 text-end">+$64.72</div>
            </div>
          </div>

          <Button height={30} isFull className="!text-s">
            View details
          </Button>
        </div>
      ) : (
        <div className="h-[50vh] flex justify-center items-center">
          <div className="flex flex-col justify-center items-center lg:-translate-x-1/2">
            <img src={folder} alt="folder" className="mt-2.5" />

            <div className="mt-3.25 text-xs font-medium">You have no position in this pool</div>

            <div className="my-3.25 text-sp text-light-500">
              Deposit some tokens to open a position !
            </div>

            <Button
              onClick={() => {
                setIsDeposit(true);
              }}
              width={167}
              height={32}
              className="font-bold">
              Deposit now
            </Button>
          </div>
        </div>
      )}
    </div>
  );
});
