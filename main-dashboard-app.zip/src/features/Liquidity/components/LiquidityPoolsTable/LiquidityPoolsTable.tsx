import { FC, memo, useState } from 'react';
import SimpleBar from 'simplebar-react';
import { pools } from '../../../../db/pools';
import { Pool } from '../../../../types/Pool';
import { numberWithCommas } from '../../../helpers';
import classicIcon from '../../../../assets/icons/classicIcon.svg';
import stableIcon from '../../../../assets/icons/stableIcon.svg';
import whiteSmallArrow from '../../../../assets/icons/whiteSmallArrow.svg';
import { useNavigate } from 'react-router-dom';

export const LiquidityPoolsTable: FC = memo(() => {
  const [allPools, setAllPools] = useState<Pool[]>([...pools]);
  const navigate = useNavigate();

  return (
    <div className="card overflow-hidden">
      <SimpleBar className="max-h-[704px]">
        <table className="min-w-[1517px] text-left text-sp">
          <thead className="font-medium text-cyan bg-dark-500 sticky top-0">
            <tr>
              <th scope="col" className="pl-12.5 py-6">
                <div className="flex gap-2">
                  POOL
                  <img
                    src={whiteSmallArrow}
                    alt="whiteSmallArrow"
                    className="flip cursor-pointer"
                    onClick={() => {
                      setAllPools(
                        [...allPools].sort((a, b) => a.fromName.localeCompare(b.fromName))
                      );
                    }}
                  />
                </div>
              </th>
              <th scope="col" className="py-6">
                <div className="flex gap-2">
                  TYPE
                  <img
                  onClick={() => {
                    setAllPools(
                      [...allPools].sort((a, b) => a.type.localeCompare(b.type))
                    );
                  }}
                    src={whiteSmallArrow}
                    alt="whiteSmallArrow"
                    className="flip cursor-pointer"
                  />
                </div>
              </th>
              <th scope="col" className="text-end py-6">
                <div className="flex gap-2 justify-end">
                  LIQUIDITY
                  <img
                   onClick={() => {
                    setAllPools(
                      [...allPools].sort((a, b) => a.liquidity - b.liquidity)
                    );
                  }}
                    src={whiteSmallArrow}
                    alt="whiteSmallArrow"
                    className="flip cursor-pointer"
                  />
                </div>
              </th>
              <th scope="col" className="pr-12.5 text-end py-6">
                <div className="flex gap-2 justify-end">
                  APR
                  <img
                   onClick={() => {
                    setAllPools(
                      [...allPools].sort((a, b) => a.APR - b.APR)
                    );
                  }}
                    src={whiteSmallArrow}
                    alt="whiteSmallArrow"
                    className="flip cursor-pointer"
                  />
                </div>
              </th>
            </tr>
          </thead>
          <tbody className="[&>*:nth-child(even)]:bg-[#00000033] text-xs">
            {allPools.map((pool) => {
              const { id, fromName, fromIcon, toName, toIcon, type, liquidity, APR } = pool;
              return (
                <tr
                  key={id}
                  onClick={() => navigate(`/Liquidity/${id}/overview`)}
                  className="transition duration-300 ease-in-out hover:!bg-dark-100 cursor-pointer">
                  <td className="whitespace-nowrap pl-12.5 py-6">
                    <div className="flex items-center max-w-min">
                      <img src={fromIcon} alt="fromIcon" className="w-4" />

                      <div className="ml-2">{fromName}</div>

                      <img src={toIcon} alt="toIcon" className="w-4 ml-4" />

                      <div className="ml-2">{toName}</div>
                    </div>
                  </td>
                  <td className="whitespace-nowrap py-6 flex items-center gap-1.25 max-w-min">
                    <img src={type === 'Classic' ? classicIcon : stableIcon} alt="icon" />

                    {type}
                  </td>
                  <td className="whitespace-nowrap text-end py-6">
                    ${numberWithCommas(liquidity)}
                  </td>
                  <td className="whitespace-nowrap pr-12.5 text-end py-6">{APR}%</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </SimpleBar>
    </div>
  );
});
