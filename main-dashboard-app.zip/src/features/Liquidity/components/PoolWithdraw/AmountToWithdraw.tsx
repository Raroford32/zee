import { FC, memo, useState } from 'react';
import settingsWhite from '../../../../assets/icons/settingsWhite.svg';
import { RadioGroup, Tab } from '@headlessui/react';
import classNames from 'classnames';
import ETH from '../../../../assets/icons/cryptocurrenciesIcons/ETH.svg';
import DOGE from '../../../../assets/icons/cryptocurrenciesIcons/DOGE.svg';
import { SwitchItem } from '../../../../components/SwitchItem';
import { Button } from '../../../../components/Button';

export const AmountToWithdraw: FC = memo(() => {
  const [rangeValue, setRangeValue] = useState('0');
  const [plan, setPlan] = useState('ETH');

  return (
    <div className="card p-5 pt-3 min-w-[339px] grow lg:grow-0">
      <div className="flex justify-between text-sp">
        Amount to withdraw
        <img src={settingsWhite} alt="settingsWhite" />
      </div>

      <div className={classNames("mt-5 text-light-500 font-medium", {
        'text-white': +rangeValue > 0
      })}>{(+rangeValue).toFixed(2)}</div>

      <div className="flex justify-between text-s text-light-500">
        $0
        <div className=""> 🛈 Available: 0.000000000000001</div>
      </div>

      <input
        id="default-range"
        type="range"
        value={rangeValue}
        onChange={(e) => {
          setRangeValue(e.target.value);
        }}
        className="w-full h-px bg-light-500 appearance-none rounded-lg cursor-pointer range-sm accent-cyan [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:h-[8px] [&::-webkit-slider-thumb]:w-[8px] [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-cyan"></input>

      <div className="mt-2.5 flex justify-between text-s text-light-500">
        <div
          onClick={() => {
            setRangeValue('25');
          }}
          className="bg-dark-900 h-3.5 w-[61px] rounded-full flex items-center cursor-pointer hover:bg-dark-500 justify-center">
          25%
        </div>
        <div
          onClick={() => {
            setRangeValue('50');
          }}
          className="bg-dark-900 h-3.5 w-[61px] rounded-full flex items-center cursor-pointer hover:bg-dark-500 justify-center">
          50%
        </div>
        <div
          onClick={() => {
            setRangeValue('75');
          }}
          className="bg-dark-900 h-3.5 w-[61px] rounded-full flex items-center cursor-pointer hover:bg-dark-500 justify-center">
          75%
        </div>
        <div
          onClick={() => {
            setRangeValue('100');
          }}
          className="bg-dark-900 h-3.5 w-[61px] rounded-full flex items-center cursor-pointer hover:bg-dark-500 justify-center">
          Max
        </div>
      </div>

      <Tab.Group>
        <Tab.List className="rounded bg-dark-900 mt-7.5 h-6 p-1 text-sp text-light-500 font-medium flex">
          <Tab
            className={({ selected }) =>
              classNames('rounded-sm flex items-center justify-center gap-1 flex-grow', {
                'bg-cyan text-white': selected
              })
            }>
            Single
          </Tab>
          <Tab
            className={({ selected }) =>
              classNames('rounded-sm flex items-center justify-center gap-1 flex-grow', {
                'bg-cyan text-white': selected
              })
            }>
            Balanced
          </Tab>
        </Tab.List>
      </Tab.Group>

      <div className="py-2.5 border-b border-primaryBorder text-s text-light-500">
        🛈 You will only receive the single token of your choice
      </div>

      <div className="pt-1  pb-5 border-b border-primaryBorder">
        <RadioGroup value={plan} onChange={setPlan}>
          <RadioGroup.Label className="text-light-500 text-sp">
            Expected to receive 🛈
          </RadioGroup.Label>

          <RadioGroup.Option value="ETH">
            {({ checked }) => (
              <div className="flex justify-between text-sp font-medium cursor-pointer">
                <div className="flex items-center gap-1.25">
                  <div
                    className={`w-1 h-1 rounded-full px-px border border-cyan ${checked && 'bg-cyan'}`}></div>
                  <img src={ETH} alt="eth" className="w-4" />
                  ETH
                </div>

                <div className="">38.789</div>
              </div>
            )}
          </RadioGroup.Option>
          <RadioGroup.Option value="DOGE">
            {({ checked }) => (
              <div className="flex justify-between text-sp font-medium cursor-pointer mt-2.5">
                <div className="flex items-center gap-1.25">
                  <div
                    className={`w-1 h-1 rounded-full px-px border border-cyan ${checked && 'bg-cyan'}`}></div>
                  <img src={DOGE} alt="DOGE" className="w-4" />
                  DOGE
                </div>

                <div className="">226.269</div>
              </div>
            )}
          </RadioGroup.Option>
        </RadioGroup>
      </div>

      <div className="flex justify-between mt-4.5 text-sp">
      Collect as WETH 🛈
        <SwitchItem/>
      </div>

      <div className="mt-1 text-light-500 text-s">Slippage 🛈</div>

      <Button isFull className='!text-sp mt-1' height={22}>Insufficient Balance</Button>
    </div>
  );
});
