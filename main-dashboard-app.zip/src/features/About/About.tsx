import { FC, memo } from 'react';

export const About: FC = memo(() => {
  return <div>About</div>;
});
