import { FC, memo, useState, useEffect, Fragment } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAppDispatch, useAppSelector } from "../../store";
import SimpleBarReact from "simplebar-react";
import classNames from "classnames";

import { tradings } from "../../db/tradings";
import { SwapConvertor } from "./components/SwapConvertor";
import { SwapChart } from "./components/SwapChart";
import { TradeHistory } from "./components/TradeHistory";
import { ChartDataItem, ICoinGeckoMarket } from "../../types/Currency";
import { fetchCoin } from "../../store/coinSlice";
import { fetchTopListCoins } from "../../store/coinsSlice";
import { newCoins } from "../../db/newCoins";
import { fetchApiChart, setDays } from "../../store/chartApiSlice";
import USDT from "../../assets/icons/cryptocurrenciesIcons/USDT.svg";

import rocket from "../../assets/icons/rocket.svg";
import info from "../../assets/icons/info.svg";
import cart from "../../assets/icons/cart.svg";

const dataChart = [
  {
    days: 1,
    label: "1H",
  },
  {
    days: 4,
    label: "4H",
  },
  {
    days: 24,
    label: "1D",
  },
  {
    days: 168,
    label: "1W",
  },
  {
    days: 200,
    label: "1M",
  },
  {
    days: 268,
    label: "6M",
  },
];

export const Swap: FC = memo(() => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const {
    coins,
    status: statusCoins,
    currencyFrom,
    currencyTo,
  } = useAppSelector((state) => state.coins);
  const { coin, status: statusCoin } = useAppSelector((state) => state.coin);
  const { chartData, days } = useAppSelector((state) => state.chart);

  useEffect(() => {
    if (coins.length === 0) {
      dispatch(fetchTopListCoins());
      dispatch(fetchCoin());
    }

    // eslint-disable-next-line
  }, []);

  const [currChartData, setCurrChartData] = useState<ChartDataItem[]>([]);
  const [chartDataFilter, setChartDataFilter] = useState(dataChart[2].days);
  const [trendingData, setTrendingData] =
    useState<ICoinGeckoMarket[]>(newCoins);

  useEffect(() => {
    if (statusCoin === "resolved") {
      setTrendingData([...coin, ...coins]);
    }

    if (statusCoins === "resolved") {
      setTrendingData([...coin, ...coins]);
    }

    // eslint-disable-next-line
  }, [statusCoins, statusCoin]);

  useEffect(() => {
    if (days !== chartDataFilter) {
      dispatch(fetchApiChart(chartDataFilter));
      dispatch(setDays(chartDataFilter));
    }

    setCurrChartData(
      chartData.prices.map((item: number[]) => ({
        time: item[0] / 1000,
        value: item[1],
        open: item[1],
        high: item[1],
        low: 0,
        close: 0,
      }))
    );

    // eslint-disable-next-line
  }, [chartDataFilter, chartData]);

  // eslint-disable-next-line
  useEffect(() => navigate("/Swap"), []);

  return (
    <div className="container px-4 my-7.5 sm:px-0">
      <div className="flex gap-4 text-xs font-medium justify-between text-center">
        <div className="flex gap-2 whitespace-nowrap items-center">
          Trending Soon
          <img src={rocket} alt="rocket" />
        </div>

        <div className="grow overflow-hidden">
          <SimpleBarReact>
            <div className="flex">
              {trendingData.map((item, i) => {
                const {
                  image: logo,
                  symbol: name,
                  current_price: price,
                  price_change_percentage_24h_in_currency: percent,
                } = item;

                return (
                  <Fragment key={i}>
                    <div className="flex px-5 items-center shrink-0 text-lg">
                      <img
                        src={logo}
                        alt={name + "Logo"}
                        width={30}
                        className="rounded"
                      />

                      <span className="ml-1.5">{name.toLocaleUpperCase()}</span>
                      <span className="ml-3.5 whitespace-nowrap">
                        {price.toFixed(4)}{" "}
                        <span className="text-cyan">
                          ({percent ? percent.toFixed(2) : 0}%)
                        </span>
                      </span>
                      <div className="ml-1.5 cursor-pointer simple-hover shrink-0 w-7 h-7 flex items-center justify-center bg-gray rounded-full">
                        <img src={info} alt="info" />
                      </div>
                      <div className="ml-1.5 cursor-pointer simple-hover shrink-0 w-7 h-7 flex items-center justify-center bg-cyanSuperDark rounded-full">
                        <img src={cart} alt="cart" />
                      </div>
                    </div>

                    {tradings.length - 1 !== i && (
                      <span className="border-r-2 border-dark-300"></span>
                    )}
                  </Fragment>
                );
              })}
            </div>
          </SimpleBarReact>
        </div>

        <Link className="flex items-center text-cyan underline" to="/Discover">
          Discover more
        </Link>
      </div>

      <div className="mt-12 flex flex-col xl:flex-row gap-7.5">
        <SwapConvertor />

        <div className="flex flex-col gap-7.5 grow">
          <div className="card grow flex justify-evenly flex-col overflow-hidden">
            <div className="mt-7.5 mb-6 flex text-sm text-light-300 items-end sm:items-center">
              <div className="w-[80px] text-center text-xl">$</div>

              <div className="grow flex justify-between flex-col lg:flex-row mx-7.5 items-center gap-2">
                <div className="rounded-lg bg-dark-900 flex items-center py-3">
                  <div className="px-2 lg:px-5 flex items-center gap-2">
                    <div className="flex">
                      <img
                        src={
                          "https://assets.coingecko.com/coins/images/1/large/bitcoin.png?1696501400"
                        }
                        alt={currencyFrom}
                        className="relative z-10 -mr-2 "
                        width={28}
                      />
                      <img src={USDT} alt={currencyTo} width={28} height={28} />
                    </div>

                    <div className="text-[22px] text-white">
                      BTC
                      <span className="text-base text text-light-300">
                        /USDT
                      </span>
                    </div>
                  </div>

                  <div className="h-7	border-r border-primaryBorder"></div>

                  <div className="px-2 lg:px-5 text-2xl font-medium">
                    1859.07 {currencyTo.toUpperCase()}
                  </div>

                  <div className="h-7	border-r border-primaryBorder"></div>

                  <div className="px-2 lg:px-5 text-end text-sm">
                    <div className="text-cyan">61.4700 (3.42%)</div>
                    <div className="text-light-500">Past 24 hours</div>
                  </div>
                </div>

                <div className="rounded-lg bg-dark-900 flex h-[50px] p-1.25 text-xl">
                  {dataChart.map(({ days, label }, i) => (
                    <div
                      key={i}
                      onClick={() => setChartDataFilter(days)}
                      className={classNames(
                        "rounded-md flex items-center cursor-pointer hover:bg-dark-300 justify-center p-1.5",
                        {
                          "gradient text-dark-900": chartDataFilter === days,
                        }
                      )}
                    >
                      {label}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="relative">
              <SwapChart data={currChartData} />
            </div>
          </div>

          <TradeHistory />
        </div>
      </div>
    </div>
  );
});
