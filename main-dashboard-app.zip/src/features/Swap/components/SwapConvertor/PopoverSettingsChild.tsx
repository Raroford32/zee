import { FC, Fragment, memo, useEffect, useState } from 'react';
import { Popover, Tab, Transition } from '@headlessui/react';
import settings from '../../../../assets/icons/settings.svg';
import settingsActive from '../../../../assets/icons/settingsActive.svg';
import info from '../../../../assets/icons/info.svg';
import classNames from 'classnames';
import { SwitchItem } from '../../../../components/SwitchItem';
import { Blur } from '../../../../components/Blur';

interface Props {
  open: boolean;
}

export const PopoverSettingsChild: FC<Props> = memo(({ open }) => {
  const [isBlur, setIsBlur] = useState(false);

  useEffect(() => {
    setIsBlur(open);
  }, [open, setIsBlur]);
  return (
    <>
    <Blur indexNegative isOpen={isBlur} />

      <Popover.Button>
        <img src={open ? settingsActive : settings} alt="settingsIcon" />
      </Popover.Button>

      <Transition
        as={Fragment}
        enter="transition ease-out duration-200"
        enterFrom="opacity-0 translate-y-1"
        enterTo="opacity-100 translate-y-0"
        leave="transition ease-in duration-150"
        leaveFrom="opacity-100 translate-y-0"
        leaveTo="opacity-0 translate-y-1">
        <Popover.Panel className="bg-dark-300 absolute text-white top-[116px] right-5 w-[222px] rounded-lg border border-primaryBorder p-2.5">
          <div className="text-sp font-medium">Settings</div>

          <div className="text-[9px] mt-2.5">Advanced Settings</div>

          <div className="flex text-[7px] mt-2">
            Max Slippage
            <img src={info} alt="info" className="w-2.5 ml-px" />
          </div>

          <div className="bg-dark-900 text-smaller rounded-sm p-px flex justify-between text-light-300 mt-2">
            <Tab.Group>
              <Tab.List>
                <Tab
                  className={({ selected }) =>
                    classNames('h-full px-1.5 rounded-sm', { 'gradient text-black': selected })
                  }>
                  0.05%
                </Tab>
                <Tab
                  className={({ selected }) =>
                    classNames('h-full px-1.5 rounded-sm', { 'gradient text-black': selected })
                  }>
                  0.1%
                </Tab>
                <Tab
                  className={({ selected }) =>
                    classNames('h-full px-1.5 rounded-sm', { 'gradient text-black': selected })
                  }>
                  0.5%
                </Tab>
                <Tab
                  className={({ selected }) =>
                    classNames('h-full px-1.5 rounded-sm', { 'gradient text-black': selected })
                  }>
                  1%
                </Tab>
              </Tab.List>
            </Tab.Group>

            <input type="text" className="bg-transparent text-end mr-2.5" placeholder="Custom %" />
          </div>

          <div className="mt-3.5 bg-dark-900 rounded border border-primaryBorder text-[7px]">
            <div className="p-2.5 border-b border-primaryBorder flex flex-col gap-2">
              <div className="flex justify-between">
                <div className="gap-1 flex items-center">
                  Transaction time limit <img src={info} alt="info" className="w-2" />
                </div>
                20 min
              </div>

              <div className="flex justify-between">
                <div className="gap-1 flex items-center">
                  Advanced Mode <img src={info} alt="info" className="w-2" />
                </div>

                <SwitchItem />
              </div>

              <div className="flex justify-between">
                <div className="gap-1 flex items-center">
                  Liquidity Sourses <img src={info} alt="info" className="w-2" />
                </div>
                16 out of 16 selected
              </div>
            </div>

            <div className="p-2.5 flex flex-col gap-2">
              <div className="text-sp">Display Settings</div>

              <div className="flex justify-between">
                <div className="gap-1 flex items-center">
                  Trending Soon <img src={info} alt="info" className="w-2" />
                </div>
                <SwitchItem isReversed />
              </div>

              <div className="flex justify-between">
                <div className="gap-1 flex items-center">
                  Live Chart <img src={info} alt="info" className="w-2" />
                </div>

                <SwitchItem isReversed />
              </div>

              <div className="flex justify-between">
                <div className="gap-1 flex items-center">
                  Trade Route <img src={info} alt="info" className="w-2" />
                </div>
                <SwitchItem isReversed />
              </div>

              <div className="flex justify-between">
                <div className="gap-1 flex items-center">
                  Token Info <img src={info} alt="info" className="w-2" />
                </div>
                <SwitchItem isReversed />
              </div>
            </div>
          </div>
        </Popover.Panel>
      </Transition>
    </>
  );
});
