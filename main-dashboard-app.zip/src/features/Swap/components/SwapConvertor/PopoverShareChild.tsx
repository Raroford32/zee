import { FC, Fragment, memo, useEffect, useState } from 'react';
import { Popover, Transition } from '@headlessui/react';
import share from '../../../../assets/icons/share.svg';
import shareActive from '../../../../assets/icons/shareActive.svg';
import largeTelegram from '../../../../assets/icons/socials/largeTelegram.svg';
import largeTwitter from '../../../../assets/icons/socials/largeTwitter.svg';
import largeDiscord from '../../../../assets/icons/socials/largeDiscord.svg';
import largeFacebook from '../../../../assets/icons/socials/largeFacebook.svg';
import { Blur } from '../../../../components/Blur';

interface Props {
  open: boolean;
}

export const PopoverShareChild: FC<Props> = memo(({ open }) => {
  const [isBlur, setIsBlur] = useState(false);
  useEffect(() => {
    setIsBlur(open);
  }, [open, setIsBlur]);
  return (
    <>
    <Blur indexNegative isOpen={isBlur} />

      <Popover.Button>
        <img src={open ? shareActive : share} alt="shareIcon" />
      </Popover.Button>

      <Transition
        as={Fragment}
        enter="transition ease-out duration-200"
        enterFrom="opacity-0 translate-y-1"
        enterTo="opacity-100 translate-y-0"
        leave="transition ease-in duration-150"
        leaveFrom="opacity-100 translate-y-0"
        leaveTo="opacity-0 translate-y-1">
        <Popover.Panel className="bg-dark-300 absolute top-[116px] right-5 w-[260px] rounded-lg border border-primaryBorder px-3.25 py-5">
          <div className="text-sp text-white font-medium">Share this with your friends!</div>

          <div className="flex justify-between text-[7px] mt-9">
            <a href='https://telegram.org/' className="flex flex-col gap-2.5">
              <img src={largeTelegram} alt="largeTelegram" className="h-7 justify-center" />

              <div className="text-center">Telegram</div>
            </a>

            <a href='https://twitter.com/home' className="flex flex-col gap-2.5">
              <img src={largeTwitter} alt="largeTwitter" className="h-7 justify-center" />

              <div className="text-center">Twitter</div>
            </a>

            <a href='https://discord.com/' className="flex flex-col gap-2.5">
              <img src={largeDiscord} alt="largeDiscord" className="h-7 justify-center" />

              <div className="text-center"> Discord</div>
            </a>

            <a href='https://www.facebook.com/' className="flex flex-col gap-2.5">
              <img src={largeFacebook} alt="largeFacebook" className="h-7 justify-center" />

              <div className="text-center">Facebook</div>
            </a>
          </div>

          <div className="mt-6.5 h-5 text-[7px] rounded bg-dark-900 flex justify-between p-px">
            <div className="text-white flex items-center ml-2">
              https://kyberswap.com/swap/ethereum?inputCu
            </div>

            <div
              className="gradient rounded-sm text-black flex items-center justify-center font-medium px-1 cursor-pointer"
              onClick={() => {
                navigator.clipboard.writeText('https://kyberswap.com/swap/ethereum?inputCu');
              }}>
              Copy Link
            </div>
          </div>
        </Popover.Panel>
      </Transition>
    </>
  );
});
