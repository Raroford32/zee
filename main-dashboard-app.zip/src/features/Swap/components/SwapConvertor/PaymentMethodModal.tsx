import { FC, Fragment, memo, useState } from 'react';
import { Button } from '../../../../components/Button';
import { Listbox, Tab } from '@headlessui/react';
import classNames from 'classnames';

import sepa from '../../../../assets/icons/currencies/sepa.png';
import visa from '../../../../assets/icons/currencies/visa.svg';
import advcashIcon from '../../../../assets/icons/cryptocurrenciesIcons/WOO.svg';
import advcashIcon2 from '../../../../assets/icons/cryptocurrenciesIcons/RVN.svg';
import graySmallArrow from '../../../../assets/icons/graySmallArrow.svg';
import { Currency } from '../../../../types/Currency';

interface Props {
  currencies: Currency[];
  setIsOpen: (open: boolean) => void;
  onOpen: (open: boolean) => void;
}

export const PaymentMethodModal: FC<Props> = memo(({ currencies, setIsOpen, onOpen }) => {
  const [selectedCurrency, setSelectedCurrency] = useState(currencies[0]);
  return (
    <div className="w-[379px] font-Ubuntu text-white bg-dark-100 overflow-hidden border border-primaryBorder px-6.5 py-5.25 rounded-lg">
      <div className="text-sm">Select currency and payment method</div>

      <div className="mt-5">
        <div className="text-sp">Currency</div>

        <Listbox value={selectedCurrency} onChange={setSelectedCurrency}>
          <Listbox.Button className="bg-dark-900 h-9 rounded px-2.5 flex items-center justify-between w-full mt-2.5">
            <div className="flex gap-1.5 items-end">
              <img
                src={selectedCurrency.icon}
                alt="selectedCurrency"
                className="w-4 mb-auto mt-auto"
              />
              <span className="text-sm">{selectedCurrency.name}</span>
              <span className="text-sp text-light-500">{selectedCurrency.fullName}</span>
            </div>

            <img src={graySmallArrow} alt="graySmallArrow" />
          </Listbox.Button>
          <Listbox.Options>
            {currencies.map((currency, i) => (
              <Listbox.Option key={i} value={currency} as={Fragment}>
                {({ active, selected }) => (
                  <li
                    className={classNames(
                      'bg-dark-900 px-2.5 cursor-pointer py-1 flex items-center',
                      {
                        '!bg-dark-200': active,
                        'border-l border-cyan': selected
                      }
                    )}>
                    <div className="flex gap-1.5 items-end">
                      <img
                        src={currency.icon}
                        alt="selectedCurrency"
                        className="w-4 mb-auto mt-auto"
                      />
                      <span className="text-sm">{currency.name}</span>
                      <span className="text-sp text-light-500">{currency.fullName}</span>
                    </div>
                  </li>
                )}
              </Listbox.Option>
            ))}
          </Listbox.Options>
        </Listbox>
      </div>

      <div className="mt-2.5">
        <div className="text-sp">Recommended</div>

        <Tab.Group>
          <Tab.List className="flex  gap-2.5 mt-2.5">
            <Tab
              className={({ selected }) =>
                classNames(
                  'bg-dark-300 border border-transparent rounded flex items-center w-[137px] gap-1.25 px-2.5 h-9',
                  {
                    '!border-cyan': selected
                  }
                )
              }>
              <img src={sepa} alt="sepa" className="w-3.25" />

              <div className="text-start">
                <div className="text-sp">Bank Transfer(SEPA)</div>
                <div className="text-smaller text-cyan">+ 0.8EUR Fee</div>
              </div>
            </Tab>
            <Tab
              className={({ selected }) =>
                classNames(
                  'bg-dark-300 border border-transparent rounded flex items-center w-[137px] gap-1.25 px-2.5 h-9',
                  {
                    '!border-cyan': selected
                  }
                )
              }>
              <img src={visa} alt="visa" className="w-3.25" />

              <div className="text-start">
                <div className="text-sp">Bank Card (Visa)</div>
                <div className="text-smaller text-cyan">+ 1% Fee Instant to your card</div>
              </div>
            </Tab>
          </Tab.List>
        </Tab.Group>
      </div>

      <div className="mt-2.5">
        <div className="text-sp">Other Payments</div>

        <Tab.Group>
          <Tab.List className="flex  gap-2.5 mt-2.5">
            <Tab
              className={({ selected }) =>
                classNames(
                  'bg-dark-300 border border-transparent rounded flex items-center flex-1 gap-1.25 px-2.5 h-9',
                  {
                    '!border-cyan': selected
                  }
                )
              }>
              <img src={advcashIcon} alt="advcash" className="w-3.25" />

              <div className="text-start">
                <div className="text-sp">Advcash Account Balance</div>
                <div className="text-smaller text-cyan">+ 0 Fee</div>
              </div>
            </Tab>
            <Tab
              className={({ selected }) =>
                classNames(
                  'bg-dark-300 border border-transparent rounded flex items-center flex-1 gap-1.25 px-2.5 h-9',
                  {
                    '!border-cyan': selected
                  }
                )
              }>
              <img src={advcashIcon2} alt="advcashIcon2" className="w-3.25" />

              <div className="text-start">
                <div className="text-sp">Advcash Account Balance</div>
                <div className="text-smaller text-cyan">+ 1% Fee Instant to your card</div>
              </div>
            </Tab>
          </Tab.List>
        </Tab.Group>
      </div>

      <Button
        onClick={() => {
          setIsOpen(false);
          onOpen(true);
        }}
        isFull
        className="mt-5.25">
        SWAP
      </Button>
    </div>
  );
});
