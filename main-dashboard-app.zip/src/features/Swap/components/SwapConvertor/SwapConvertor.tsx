import { FC, memo, useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "../../../../store";

import { Popover, Tab } from "@headlessui/react";
import classNames from "classnames";

import search from "../../../../assets/icons/search.svg";
import wallet from "../../../../assets/icons/wallet.svg";
import upDownArrows from "../../../../assets/icons/upDownArrows.svg";
import reload from "../../../../assets/icons/reload.svg";
import swap from "../../../../assets/icons/swap.svg";
import clock from "../../../../assets/icons/clock.svg";
import info from "../../../../assets/icons/info.svg";
import graySmallArrow from "../../../../assets/icons/graySmallArrow.svg";
import whiteSmallArrow from "../../../../assets/icons/whiteSmallArrow.svg";
import gas from "../../../../assets/icons/gas.svg";
import gasBlack from "../../../../assets/icons/gasBlack.svg";
import coinIcon from "../../../../assets/icons/coin.svg";
import coinBlack from "../../../../assets/icons/coinBlack.svg";

import { Button } from "../../../../components/Button";
import { numberWithCommas } from "../../../helpers";
import { PopoverPlayerChild } from "./PopoverPlayerChild";
import { PopoverInfoChild } from "./PopoverInfoChild";
import { PopoverShareChild } from "./PopoverShareChild";
import { PopoverSettingsChild } from "./PopoverSettingsChild";

import { PopoverFromChild } from "./PopoverFromChild";
import { currencies } from "../../../../db/currencies";
import { PopoverToChild } from "./PopoverToChild";
import { Modal } from "../../../../components/Modal";
import { PaymentMethodModal } from "./PaymentMethodModal";
import { WithdrawalInfoModal } from "./WithdrawalInfoModal";
import { ICoinGeckoMarket } from "../../../../types/Currency";
import { newCoins } from "../../../../db/newCoins";
import { setCurrencyFrom, setCurrencyTo } from "../../../../store/coinsSlice";

export const SwapConvertor: FC = memo(() => {
  const { coins } = useAppSelector((state) => state.coins);
  const coin = useAppSelector((state) => state.coin.coin);

  const dispatch = useAppDispatch();

  const [currenciesFrom, setCurrenciesFrom] =
    useState<ICoinGeckoMarket[]>(newCoins);

  const [selectedCurrencyFrom, setSelectedCurrencyFrom] = useState(
    currenciesFrom[0]
  );

  const [selectedCurrencyTo, setSelectedCurrencyTo] = useState(
    currenciesFrom[0]
  );

  useEffect(() => {
    if (coins.length !== 0 && coin.length !== 0) {
      setCurrenciesFrom([...coin, ...coins]);
    }
  }, [coins, coin]);

  useEffect(() => {
    if (currenciesFrom.length > 1) {
      setSelectedCurrencyFrom(currenciesFrom[1]);
      setSelectedCurrencyTo(currenciesFrom[0]);
    }
  }, [coins, coin, currenciesFrom]);

  useEffect(() => {
    dispatch(setCurrencyFrom(selectedCurrencyFrom.symbol));
    dispatch(setCurrencyTo(selectedCurrencyTo.symbol));

    //eslint-disable-next-line
  }, [selectedCurrencyFrom, selectedCurrencyTo]);

  const [calculatorResult, setCalculatorResult] = useState("0.00");

  const [inputFrom, setInputFrom] = useState("1");
  const [swapTo, setSwapTo] = useState("Crypto");
  const [isReversed, setIsReversed] = useState(false);

  const [isPaymentMethodModalOpen, setIsPaymentMethodModalOpen] =
    useState(false);
  const [isWithdrawalInfoModalOpen, setIsWithdrawalInfoModalOpen] =
    useState(false);

  useEffect(() => {
    if (currenciesFrom.length !== 0) {
      const swapResult =
        (+inputFrom * selectedCurrencyFrom.current_price) /
        selectedCurrencyTo.current_price;
      setCalculatorResult(swapResult.toFixed(3));
    }
    //eslint-disable-next-line
  }, [inputFrom, selectedCurrencyFrom, selectedCurrencyTo]);

  return (
    <>
      <div className="min-w-full sm:min-w-[410px] card  text-light-300 z-30">
        <div className="bg-dark-100 rounded-t-lg py-7.5 px-4 border-b border-primaryBorder flex relative z-10 justify-between">
          <div className="text-lg flex gap-2.5 items-center">
            Swap to:
            <div className="bg-dark-900 p-1 h-9 text-sm rounded flex">
              <div
                onClick={() => setSwapTo("Crypto")}
                className={classNames(
                  "h-full px-2 rounded flex items-center cursor-pointer",
                  {
                    "bg-cyan text-dark-900": swapTo === "Crypto",
                  }
                )}
              >
                Crypto
              </div>

              <div
                onClick={() => setSwapTo("Fiat")}
                className={classNames(
                  "h-full px-2 rounded flex items-center cursor-pointer hidden",
                  {
                    "bg-cyan text-dark-900": swapTo === "Fiat",
                  }
                )}
              >
                Fiat
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            <Popover className="shrink-0 flex items-center">
              {({ open }) => {
                return <PopoverPlayerChild open={open} />;
              }}
            </Popover>

            <Popover className="shrink-0 flex items-center">
              {({ open }) => {
                return <PopoverInfoChild open={open} />;
              }}
            </Popover>

            <Popover className="shrink-0 flex items-center">
              {({ open }) => {
                return <PopoverShareChild open={open} />;
              }}
            </Popover>

            <Popover className="shrink-0 flex items-center">
              {({ open }) => {
                return <PopoverSettingsChild open={open} />;
              }}
            </Popover>
          </div>
        </div>

        <div className="py-5 px-4 rounded-b-lg">
          <div className="text-[10px]">
            Buy or sell any token instantly at the best price
          </div>

          <label className=" bg-dark-900 rounded mt-7.5 flex px-2 h-9 items-center gap-2">
            <img src={search} alt="search" />

            <input
              type="text"
              className="placeholder-light-500 text-sm focus:outline-none bg-transparent grow"
              id="swapSearch"
              placeholder='Try typing "10 ETH to BTC"'
            />

            <div className="text-light-500 mr-2.5 text-[10px]">Ctlr+K</div>
          </label>

          <div className="relative mt-8 flex flex-col gap-1.25 font-medium">
            <div
              className={`bg-dark-900 flex h-20 rounded px-3.25 items-center justify-between relative `}
              style={{ order: isReversed ? 3 : 1 }}
            >
              <div className="flex flex-col justify-between text-xlp text-white w-1/2">
                <input
                  type="text"
                  value={inputFrom}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    const re = /^[0-9]*\.?[0-9]*$/;

                    // if value is not blank, then test the regex

                    if (e.target.value === "" || re.test(e.target.value)) {
                      setInputFrom(e.target.value);
                    }
                  }}
                  className="flex bg-transparent focus:outline-none"
                />

                <div className="text-xs text-light-500">
                  ~$
                  {numberWithCommas(selectedCurrencyFrom.current_price)}
                </div>
              </div>

              <div className="flex gap-3.25 items-center">
                <div className="flex gap-1 text-sp items-center">
                  <img src={wallet} alt="wallet" />0
                </div>

                <Popover>
                  {({ open }) => {
                    return (
                      <PopoverFromChild
                        onSelectFrom={setSelectedCurrencyFrom}
                        currencies={currenciesFrom}
                        selectedCurrencyFrom={selectedCurrencyFrom}
                        open={open}
                      />
                    );
                  }}
                </Popover>
              </div>
            </div>

            <div
              onClick={() => {
                setIsReversed(!isReversed);
              }}
              className="absolute z-[1] w-10 h-10 bg-dark-200 rounded-full centerAbsolute flex items-center justify-center cursor-pointer scale-hover"
              style={{ order: 2 }}
            >
              <img
                src={upDownArrows}
                alt="upDownArrows"
                className={classNames("transition", { flip: isReversed })}
              />
            </div>

            <div
              className={`bg-dark-900 flex h-20 rounded px-3.25 items-center justify-between relative`}
              style={{ order: isReversed ? 1 : 3 }}
            >
              <div className="flex flex-col justify-between text-xlp text-white w-1/2">
                {calculatorResult}
                <div className="text-xs text-light-500">
                  ~$
                  {numberWithCommas(selectedCurrencyFrom.current_price)}
                </div>
              </div>

              <div className="flex gap-3.25 items-center">
                <div className="flex gap-1 text-sp items-center">
                  <img src={wallet} alt="wallet" />0
                </div>

                <Popover>
                  {({ open }) => {
                    return (
                      <PopoverToChild
                        onSelectTo={setSelectedCurrencyTo}
                        selectedCurrencyFrom={selectedCurrencyTo}
                        currencies={currenciesFrom}
                        open={open}
                      />
                    );
                  }}
                </Popover>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2.5 items-center text-sp text-cyan mt-2.5">
            <img src={reload} alt="reload" />

            <span>
              {/* {inputFrom} {selectedCurrencyFrom.name} = {convertedTo.toFixed(3)} */}
              {inputFrom} {selectedCurrencyFrom.name} = {calculatorResult}
              {selectedCurrencyTo.name}
            </span>

            <img src={swap} alt="swap" />
          </div>

          <div className="mt-9 flex justify-between text-sp font-medium">
            <div className="flex items-center gap-1">
              Max Slippage
              <img src={info} alt="info" className="w-[11px]" />:
              <span className="text-xs text-white">0.5%</span>
              <img src={graySmallArrow} alt="graySmallArrow" />
            </div>

            <div className="px-1.5 h-5 flex items-center gap-1 bg-dark-900 rounded-full">
              <img src={clock} alt="clock" />
              Price Alert
            </div>
          </div>

          <Tab.Group>
            <Tab.List className="rounded bg-dark-900 mt-3.5 h-9 p-1.25 text-sp text-light-300 font-medium flex">
              <Tab
                className={({ selected }) =>
                  classNames(
                    "rounded flex items-center justify-center gap-1 flex-grow",
                    {
                      "bg-cyan text-black": selected,
                    }
                  )
                }
              >
                {({ selected }) =>
                  selected ? (
                    <>
                      <img src={coinIcon} alt="coin" /> Maximum Return
                    </>
                  ) : (
                    <>
                      <img src={coinBlack} alt="coinBlack" /> Maximum Return
                    </>
                  )
                }
              </Tab>
              <Tab
                className={({ selected }) =>
                  classNames(
                    "rounded flex items-center justify-center gap-1 flex-grow",
                    {
                      "bg-cyan text-black": selected,
                    }
                  )
                }
              >
                {({ selected }) =>
                  selected ? (
                    <>
                      <img src={gasBlack} alt="gasBlack" /> Lowest Gas
                    </>
                  ) : (
                    <>
                      <img src={gas} alt="gas" /> Lowest Gas
                    </>
                  )
                }
              </Tab>
            </Tab.List>
          </Tab.Group>

          <div className="rounded border border-primaryBorder py-1.25 px-4 mt-10">
            <div className="pb-2.5 pt-1.5 flex justify-between border-b border-primaryBorder text-sp font-medium text-white">
              MORE INFORMATION
              <img src={whiteSmallArrow} alt="whiteSmallArrow" />
            </div>

            <div className="flex justify-between text-sp mt-2.5">
              <div className="flex gap-1">
                Minimum Received
                <img src={info} alt="info" className="w-[11px]" />
              </div>

              <div className="text-white font-bold">1,852 USDT</div>
            </div>

            <div className="flex justify-between text-sp mt-2.5">
              <div className="flex gap-1">
                Gas Fee
                <img src={info} alt="info" className="w-[11px]" />
              </div>

              <div className="text-white font-bold">$16.34</div>
            </div>

            <div className="flex justify-between text-sp mt-2.5">
              <div className="flex gap-1">
                Price Impact
                <img src={info} alt="info" className="w-[11px]" />
              </div>

              <div className="text-white font-bold">{"<"} 0.01%</div>
            </div>
          </div>

          <Button
            onClick={() => {
              setIsPaymentMethodModalOpen(true);
            }}
            isFull
            className="mt-5"
          >
            SWAP
          </Button>
        </div>
      </div>

      <Modal
        isOpen={isPaymentMethodModalOpen}
        setIsOpen={setIsPaymentMethodModalOpen}
      >
        <PaymentMethodModal
          onOpen={setIsWithdrawalInfoModalOpen}
          setIsOpen={setIsPaymentMethodModalOpen}
          currencies={currencies}
        />
      </Modal>

      <Modal
        isOpen={isWithdrawalInfoModalOpen}
        setIsOpen={setIsWithdrawalInfoModalOpen}
      >
        <WithdrawalInfoModal setIsOpen={setIsWithdrawalInfoModalOpen} />
      </Modal>
    </>
  );
});
