import { FC, Fragment, memo, useContext, useEffect, useState } from "react";
import { IsBulrVisible } from "../../../../context/context";
import { Popover, Tab, Transition } from "@headlessui/react";
import graySmallArrow from "../../../../assets/icons/graySmallArrow.svg";
import classNames from "classnames";
import { Button } from "../../../../components/Button";

import star from "../../../../assets/icons/star.svg";
import starActive from "../../../../assets/icons/starActive.svg";

import { ICoinGeckoMarket } from "../../../../types/Currency";
import SimpleBar from "simplebar-react";
import { Blur } from "../../../../components/Blur";

interface Props {
  onSelectTo: (currency: ICoinGeckoMarket) => void;
  selectedCurrencyFrom: ICoinGeckoMarket;
  currencies: ICoinGeckoMarket[];
  open: boolean;
}

export const PopoverToChild: FC<Props> = memo(
  ({ onSelectTo, open, selectedCurrencyFrom, currencies }) => {
    const { setIsBlur } = useContext(IsBulrVisible);
    const [isBulrVisible, setIsBulrVisible] = useState(false);

    useEffect(() => {
      setIsBlur(open);
      setIsBulrVisible(open);
    }, [open, setIsBlur]);
    return (
      <>
        <div className="block xl:hidden">
          <Blur isAllBlured isOpen={isBulrVisible} />
        </div>

        <Popover.Button
          className={({ open }) =>
            classNames(
              "bg-dark-300 border border-transparent rounded flex items-center gap-1.5 px-1 h-9",
              {
                "!border-cyan": open,
              }
            )
          }
        >
          <img src={selectedCurrencyFrom.image} alt="icon" className="w-5" />

          {selectedCurrencyFrom.symbol.toUpperCase()}

          <img src={graySmallArrow} alt="graySmallArrow" />
        </Popover.Button>

        <Transition
          as={Fragment}
          enter="transition ease-out duration-200"
          enterFrom="opacity-0 translate-y-1"
          enterTo="opacity-100 translate-y-0"
          leave="transition ease-in duration-150"
          leaveFrom="opacity-100 translate-y-0"
          leaveTo="opacity-0 translate-y-1"
        >
          <Popover.Panel className="bg-dark-300 overflow-hidden absolute w-[365px] text-sp right-1/2 xl:-right-[50px] translate-x-1/2 xl:translate-x-full xl:top-5 rounded-lg border border-primaryBorder z-50">
            <Tab.Group>
              <div className="text-center pt-5 pb-2 bg-dark-100 px-5 border-b border-primaryBorder">
                <div className="text-white font-medium text-xs">
                  Select a token
                </div>
                <div className="mt-2">
                  You can search and select{" "}
                  <span className="text-white">any token</span> on NameLogo
                </div>

                <div className=" bg-dark-900 rounded mt-5 flex p-1 h-5.25 items-center">
                  <input
                    type="text"
                    className="placeholder-light-500 text-[7px] focus:outline-none ml-2.5 bg-transparent grow"
                    placeholder="Search by token name, token symbol or adress"
                  />

                  <Button height={"auto"} className="!px-2.5 !text-[9px]">
                    Search
                  </Button>
                </div>

                <div className="mt-3.25">
                  <Tab.Group>
                    <Tab.List className="flex justify-center gap-2 text-xs">
                      {currencies.slice(0, 3).map((item, i) => (
                        <Tab
                          onClick={() => {
                            onSelectTo(item);
                          }}
                          key={i}
                          className={({ selected }) =>
                            classNames(
                              "bg-dark-300 border border-transparent rounded flex items-center gap-1.5 px-3 h-8",
                              {
                                "!border-cyan": selected,
                              }
                            )
                          }
                        >
                          <img src={item.image} alt="icon" className="w-5" />
                          {item.name}
                        </Tab>
                      ))}
                    </Tab.List>
                  </Tab.Group>
                </div>

                <div className="mt-5 flex justify-center">
                  <Tab.List className="rounded bg-dark-900 h-6.5 p-1.25 text-sp text-light-300 font-medium flex">
                    <Tab
                      className={({ selected }) =>
                        classNames(
                          "rounded flex items-center w-20 justify-center gap-1 flex-grow",
                          {
                            "bg-cyan text-black": selected,
                          }
                        )
                      }
                    >
                      All
                    </Tab>
                    <Tab
                      className={({ selected }) =>
                        classNames(
                          "rounded flex items-center w-20 justify-center gap-1 flex-grow",
                          {
                            "bg-cyan text-black": selected,
                          }
                        )
                      }
                    >
                      Imported
                    </Tab>
                  </Tab.List>
                </div>
              </div>

              <Tab.Panels>
                <Tab.Panel>
                  <SimpleBar className="py-5 bg-dark-900 h-52">
                    {currencies.map((item, i) => {
                      const { image: icon, name, symbol: fullName } = item;
                      return (
                        <div
                          onClick={() => {
                            onSelectTo(item);
                          }}
                          key={i}
                          className="px-5 cursor-pointer flex items-center font-medium justify-between hover:bg-dark-300"
                        >
                          <div className="flex gap-1.25 items-center">
                            <img
                              src={icon}
                              alt="currencyIcon"
                              className="w-5 h-5"
                            />

                            <div className="text-xs">
                              <div className="text-white">
                                {name.toUpperCase()}
                              </div>
                              <div className="text-[7px]">{fullName}</div>
                            </div>
                          </div>

                          <img
                            src={i % 4 ? star : starActive}
                            alt="startIcon"
                          />
                        </div>
                      );
                    })}
                  </SimpleBar>
                </Tab.Panel>

                <Tab.Panel>
                  <SimpleBar className="py-5 bg-dark-900 max-h-52">
                    {currencies.map((item, i) => {
                      const { image: icon, name, symbol: fullName } = item;
                      return (
                        !(i % 4) && (
                          <div
                            onClick={() => {
                              onSelectTo(item);
                            }}
                            key={i}
                            className="px-5 cursor-pointer flex items-center font-medium justify-between hover:bg-dark-300"
                          >
                            <div className="flex gap-1.25 items-center">
                              <img
                                src={icon}
                                alt="currencyIcon"
                                className="w-5 h-5"
                              />

                              <div className="text-xs">
                                <div className="text-white">{name}</div>
                                <div className="text-[7px]">{fullName}</div>
                              </div>
                            </div>

                            <img
                              src={i % 4 ? star : starActive}
                              alt="startIcon"
                            />
                          </div>
                        )
                      );
                    })}
                  </SimpleBar>
                </Tab.Panel>
              </Tab.Panels>
            </Tab.Group>
          </Popover.Panel>
        </Transition>
      </>
    );
  }
);
