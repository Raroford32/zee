import { FC, Fragment, memo, useEffect, useState } from 'react';
import { Popover, Tab, Transition } from '@headlessui/react';
import info from '../../../../assets/icons/info.svg';
import infoActive from '../../../../assets/icons/infoActive.svg';
import classNames from 'classnames';
import USDT from '../../../../assets/icons/cryptocurrenciesIcons/USDT.svg';
import ETH from '../../../../assets/icons/chains/ETH.svg';
import { Blur } from '../../../../components/Blur';

interface Props {
  open: boolean;
}

const ethData = {
  price: '1,887',
  tradingVolume: '7,480,508,497',
  marketCapRank: 2,
  marketCap: '225,823,501,873',
  allTimeHigh: '4,878',
  allTimeLow: '0,43',
  carculatingSupply: '120,441,938',
  totalSupply: '120,641,938',
  contactAddress: '0xC02...Cc2'
};

const usdtData = {
  price: '1',
  tradingVolume: '9,180,508,497',
  marketCapRank: 4,
  marketCap: '82.91B',
  allTimeHigh: '1.1',
  allTimeLow: '0,99',
  carculatingSupply: '85.44B',
  totalSupply: '85.64B',
  contactAddress: '0xC51...Cc6'
};

export const PopoverInfoChild: FC<Props> = memo(({ open }) => {
  const [isBlur, setIsBlur] = useState(false);
  useEffect(() => {
    setIsBlur(open);
  }, [open, setIsBlur]);
  return (
    <>
      <Blur indexNegative isOpen={isBlur} />

      <Popover.Button>
        <img src={open ? infoActive : info} alt="infoIcon" />
      </Popover.Button>

      <Transition
        as={Fragment}
        enter="transition ease-out duration-200"
        enterFrom="opacity-0 translate-y-1"
        enterTo="opacity-100 translate-y-0"
        leave="transition ease-in duration-150"
        leaveFrom="opacity-100 translate-y-0"
        leaveTo="opacity-0 translate-y-1">
        <Popover.Panel className="bg-dark-300 absolute top-[116px] left-1/2 -translate-x-1/2 w-[222px] rounded-lg border border-primaryBorder p-2.5">
          <div className=" text-center text-sp font-medium text-white">Information</div>

          <Tab.Group>
            <Tab.List className="mt-3 h-3 p-px bg-dark-900 text-light-500 font-medium rounded-sm text-[7px] flex">
              <Tab
                className={({ selected }) =>
                  classNames('rounded-sm grow flex justify-center items-center gap-[2px]', {
                    'bg-cyan text-white': selected
                  })
                }>
                <img src={ETH} alt="ETH" className="w-2" />
                ETH
              </Tab>

              <Tab
                className={({ selected }) =>
                  classNames('rounded-sm grow flex justify-center items-center gap-[2px]', {
                    'bg-cyan text-white': selected
                  })
                }>
                <img src={USDT} alt="USDT" className="w-2" />
                USDT
              </Tab>
            </Tab.List>

            <Tab.Panels className="mt-3 text-light-500 bg-dark-900 rounded border border-primaryBorder text-[7px]">
              <Tab.Panel>
                <div className="flex justify-between mx-2.5 py-1.5 border-b border-primaryBorder">
                  Price
                  <span className="text-white">${ethData.price}</span>
                </div>

                <div className="flex justify-between mx-2.5 py-1.5 border-b border-primaryBorder">
                  Trading Volume (24H)
                  <span className="text-white">${ethData.tradingVolume}</span>
                </div>

                <div className="flex justify-between mx-2.5 py-1.5 border-b border-primaryBorder">
                  Market Cap Rank
                  <span className="text-white">#{ethData.marketCapRank}</span>
                </div>

                <div className="flex justify-between mx-2.5 py-1.5 border-b border-primaryBorder">
                  Market Cap
                  <span className="text-white">${ethData.marketCap}</span>
                </div>

                <div className="flex justify-between mx-2.5 py-1.5 border-b border-primaryBorder">
                  All-Time High
                  <span className="text-white">${ethData.allTimeHigh}</span>
                </div>

                <div className="flex justify-between mx-2.5 py-1.5 border-b border-primaryBorder">
                  All-Time Low
                  <span className="text-white">${ethData.allTimeLow}</span>
                </div>

                <div className="flex justify-between mx-2.5 py-1.5 border-b border-primaryBorder">
                  Carculating Supply
                  <span className="text-white">{ethData.carculatingSupply}</span>
                </div>

                <div className="flex justify-between mx-2.5 py-1.5 border-b border-primaryBorder">
                  Total Supply
                  <span className="text-white">{ethData.totalSupply}</span>
                </div>

                <div className="flex justify-between mx-2.5 py-1.5">
                  Contract Address
                  <span className="text-white">{ethData.contactAddress}</span>
                </div>
              </Tab.Panel>

              <Tab.Panel>
                <div className="flex justify-between mx-2.5 py-1.5 border-b border-primaryBorder">
                  Price
                  <span className="text-white">${usdtData.price}</span>
                </div>
                <div className="flex justify-between mx-2.5 py-1.5 border-b border-primaryBorder">
                  Trading Volume (24H)
                  <span className="text-white">${usdtData.tradingVolume}</span>
                </div>
                <div className="flex justify-between mx-2.5 py-1.5 border-b border-primaryBorder">
                  Market Cap Rank
                  <span className="text-white">#{usdtData.marketCapRank}</span>
                </div>
                <div className="flex justify-between mx-2.5 py-1.5 border-b border-primaryBorder">
                  Market Cap
                  <span className="text-white">${usdtData.marketCap}</span>
                </div>
                <div className="flex justify-between mx-2.5 py-1.5 border-b border-primaryBorder">
                  All-Time High
                  <span className="text-white">${usdtData.allTimeHigh}</span>
                </div>
                <div className="flex justify-between mx-2.5 py-1.5 border-b border-primaryBorder">
                  All-Time Low
                  <span className="text-white">${usdtData.allTimeLow}</span>
                </div>
                <div className="flex justify-between mx-2.5 py-1.5 border-b border-primaryBorder">
                  Carculating Supply
                  <span className="text-white">{usdtData.carculatingSupply}</span>
                </div>
                <div className="flex justify-between mx-2.5 py-1.5 border-b border-primaryBorder">
                  Total Supply
                  <span className="text-white">{usdtData.totalSupply}</span>
                </div>
                <div className="flex justify-between mx-2.5 py-1.5">
                  Contract Address
                  <span className="text-white">{usdtData.contactAddress}</span>
                </div>
              </Tab.Panel>
            </Tab.Panels>
          </Tab.Group>
        </Popover.Panel>
      </Transition>
    </>
  );
});
