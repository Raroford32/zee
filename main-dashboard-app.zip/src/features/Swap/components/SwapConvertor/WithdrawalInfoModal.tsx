import { FC, memo } from 'react';
import { Button } from '../../../../components/Button';

import graySmallArrow from '../../../../assets/icons/graySmallArrow.svg';

interface Props {
  setIsOpen: (open: boolean) => void;
}

export const WithdrawalInfoModal: FC<Props> = memo(({ setIsOpen }) => {
  return (
    <div className="w-[379px] font-Ubuntu text-white bg-dark-100 overflow-hidden border border-primaryBorder px-4 py-5 rounded-lg">
      <div className="text-sm text-center font-normal">Withdrawal info</div>

      <div className="mt-5">
        <div className="text-sp">Amount</div>

        <div className="mt-2.5 rounded bg-dark-300 h-9 flex justify-between items-center px-2.5">
          <div className="text-xs font-normal">100</div>
          <div className="text-sp text-light-300">
            Avaible: <span className="text-cyan">100,000 EUR</span>
          </div>
        </div>
      </div>

      <div className="mt-5 border border-primaryBorder text-sp flex flex-col gap-2.5 bg-dark-300 rounded p-2.5">
        <div className="flex justify-between">
          Transaction Fee:
          <div className="text-cyan">2.00 EUR</div>
        </div>

        <div className="flex justify-between">
          You Will Get:
          <div className="text-cyan">98.00 EUR</div>
        </div>
      </div>

      <div className="mt-5 text-center text-sp">Beneficiary’s Information</div>

      <div className="mt-3 text-sp">Amount</div>

      <div className="mt-2.5 bg-dark-300 rounded px-4 flex justify-between items-center h-9">
        <div className="ml-4 text-sp">431172******7509</div>

        <img src={graySmallArrow} alt="graySmallArrow" />
      </div>

      <Button
        onClick={() => {
          setIsOpen(false);
        }}
        isFull
        className="mt-7.5">
        CONNECT WALLET
      </Button>
    </div>
  );
});
