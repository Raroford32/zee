import { FC, memo } from 'react';
import tradeHistory from '../../../../assets/icons/tradeHistory.svg';
import SimpleBar from 'simplebar-react';
import { tradesHistory } from '../../../../db/tradeHistory';

export const TradeHistory: FC = memo(() => {
  return (
    <div className="card grow">
      <div className="text-base font-medium flex gap-2.5 p-4 text-light-300">
        <img src={tradeHistory} alt="tradeHistory" /> Your trade history
      </div>

      <SimpleBar className="h-72">
        <table className="min-w-full text-left text-sp">
          <thead className="font-medium text-light-300 bg-[#00000033]">
            <tr>
              <th scope="col" className="px-4 py-4">
                Account
              </th>
              <th scope="col" className="px-4 py-4">
                Height
              </th>
              <th scope="col" className="px-4 py-4">
                Hash
              </th>
              <th scope="col" className="px-4 py-4">
                InToken
              </th>
              <th scope="col" className="px-4 py-4">
                InAmount
              </th>
              <th scope="col" className="px-4 py-4">
                OutToken
              </th>
              <th scope="col" className="px-4 py-4">
                OutAmount
              </th>
              <th scope="col" className="px-4 py-4">
                Age
              </th>
            </tr>
          </thead>
          <tbody className="[&>*:nth-child(even)]:bg-[#00000033]">
            {tradesHistory.map((trade, i) => {
              const { account, height, hash, inToken, inAmount, outToken, outAmount, age } = trade;

              return (
                <tr key={i} className="transition duration-300 ease-in-out">
                  <td className="whitespace-nowrap px-4 py-4 font-medium">{account}</td>
                  <td className="whitespace-nowrap px-4 py-4">{height}</td>
                  <td className="whitespace-nowrap px-4 py-4 text-link">
                    <a href="https://etherscan.io/">{hash}</a>
                  </td>
                  <td className="whitespace-nowrap px-4 py-4">{inToken}</td>
                  <td className="whitespace-nowrap px-4 py-4">{inAmount}</td>
                  <td className="whitespace-nowrap px-4 py-4">{outToken}</td>
                  <td className="whitespace-nowrap px-4 py-4">{outAmount}</td>
                  <td className="whitespace-nowrap px-4 py-4">{age}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </SimpleBar>
    </div>
  );
});
