export const unixTimeConvertor = (unixTimestamp: number) => {
  // Create a new Date object using the Unix timestamp
  const date = new Date(unixTimestamp * 1000); // Multiply by 1000 to convert to milliseconds

  // Set the time zone offset to GMT+3 (180 minutes ahead of GMT)
  date.setMinutes(date.getMinutes() + 180);

  // Months in JavaScript are 0-based (0 = January, 1 = February, etc.)
  const months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec'
  ];

  // Get the components of the date
  const month = months[date.getMonth()];
  const day = date.getDate();
  const hours = date.getHours();
  const minutes = date.getMinutes();

  // Format the output as "1:10 AM Apr 11"
  return `${hours}:${minutes < 10 ? '0' : ''}${minutes} ${
    hours >= 12 ? 'PM' : 'AM'
  } ${month} ${day} (GMT +3)`;
};
