// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-nocheck

import { createChart, ColorType, CrosshairMode } from "lightweight-charts";
import { useEffect, useRef } from "react";

import { unixTimeConvertor } from "./helpers";

export const MainChartComponent = (props) => {
  const {
    data,
    colors: {
      backgroundColor = "#151515",
      lineColor = "#20D691",
      textColor = "#fff",
      areaTopColor = "rgba(49, 203, 158, 0.24)",
      areaBottomColor = "rgba(49, 203, 158, 0.00)",
      horzLinesColor = "rgba(255, 255, 255, 0.05)",
      fontSize = 14,
    } = {},
  } = props;

  const chartContainerRef = useRef();

  useEffect(() => {
    const handleResize = () => {
      chart.applyOptions({
        width: chartContainerRef.current.clientWidth,
      });
    };

    const chart = createChart(chartContainerRef.current, {
      layout: {
        // autoSize: true,
        background: { type: ColorType.Solid, color: backgroundColor },
        textColor,
        fontSize,
        fontFamily: "Ubuntu, sans-serif",
      },
      grid: {
        vertLines: {
          color: horzLinesColor,
          style: 3,
        },
        horzLines: {
          color: horzLinesColor,
          style: 3,
        },
      },
      rightPriceScale: {
        visible: false,
      },
      overlayPriceScales: {
        visible: false,
      },
      leftPriceScale: {
        borderVisible: false,
        visible: true,
        textColor: "#A9A9A9",
      },
      timeScale: {
        borderVisible: false,
        ticksVisible: false,
        fixLeftEdge: true,
        // fixRightEdge: true,
      },
      crosshair: {
        mode: CrosshairMode.Magnet,
        vertLine: {
          // visible: false,
          color: "#20D691",
          labelVisible: false,
        },
        horzLine: {
          // visible: false,
          color: "#20D691",
          labelVisible: false,
        },
      },
      width: chartContainerRef.current.clientWidth,
      height: 306,
    });

    chart.timeScale().fitContent();

    const newSeries = chart.addAreaSeries({
      priceLineVisible: false,
      lastValueVisible: false,
      crosshairMarkerBorderColor: "#fff",
      lineColor,
      topColor: areaTopColor,
      bottomColor: areaBottomColor,
      horzLinesColor,
    });
    newSeries.setData(data);

    window.addEventListener("resize", handleResize);

    const toolTipWidth = 80;
    const toolTipHeight = 80;
    const toolTipMargin = -50;

    // Create and style the tooltip html element
    const toolTip = document.createElement("div");
    toolTip.style = `position: absolute; transform: translateX(110%); margin-top: -1%; display: none; font-size: 12px; z-index: 1000;  pointer-events: none; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale;`;
    toolTip.style.background = "rgba(255, 255, 255, .0)";
    toolTip.style.color = "#FFFFFF";
    toolTip.style.borderColor = "rgba(146, 160, 186, 0.15)";
    chartContainerRef.current.appendChild(toolTip);

    // update tooltip
    chart.subscribeCrosshairMove((param) => {
      if (
        param.point === undefined ||
        !param.time ||
        param.point.x < 0 ||
        param.point.x > chartContainerRef.current.clientWidth ||
        param.point.y < 0 ||
        param.point.y > chartContainerRef.current.clientHeight
      ) {
        toolTip.style.display = "none";
      } else {
        // time will be in the same format that we supplied to setData.
        // thus it will be YYYY-MM-DD
        const dateStr = unixTimeConvertor(param.time);
        toolTip.style.display = "block";
        const data = param.seriesData.get(newSeries);
        const price = data.value !== undefined ? data.value : data.close;
        toolTip.innerHTML = `
        <div style="color: #505050">
          <div>${dateStr}</div>
        </div>

        <div>$${price.toFixed(
          2
        )} <span style="color: #20D691">(${+4.73}%)</span></div>
        `;

        const coordinate = newSeries.priceToCoordinate(price);
        let shiftedCoordinate = param.point.x - 50;
        if (coordinate === null) {
          return;
        }
        shiftedCoordinate = Math.max(
          0,
          Math.min(
            chartContainerRef.current.clientWidth - toolTipWidth,
            shiftedCoordinate
          )
        );
        const coordinateY =
          coordinate - toolTipHeight - toolTipMargin > 0
            ? coordinate - toolTipHeight - toolTipMargin
            : Math.max(
                0,
                Math.min(
                  chartContainerRef.current.clientHeight -
                    toolTipHeight -
                    toolTipMargin,
                  coordinate + toolTipMargin
                )
              );
        toolTip.style.left = shiftedCoordinate + "px";
        toolTip.style.top = coordinateY + "px";
      }
    });

    return () => {
      window.removeEventListener("resize", handleResize);

      chart.remove();
    };
  }, [
    data,
    backgroundColor,
    lineColor,
    textColor,
    areaTopColor,
    areaBottomColor,
    horzLinesColor,
  ]);

  return <div ref={chartContainerRef} />;
};

export const SwapChart = (props) => {
  return <MainChartComponent {...props}></MainChartComponent>;
};
