import { FC, memo, useState } from "react";
import { useAppSelector } from "../../store";
import SimpleBar from "simplebar-react";

import { ICoinGeckoMarket } from "../../types/Currency";

import whiteSmallArrow from "../../assets/icons/whiteSmallArrow.svg";
import actionButton from "../../assets/icons/actionButton.svg";
import actionsMoreButton from "../../assets/icons/actionsMoreButton.svg";
import { numberWithCommas } from "../helpers";
// import { newCoins } from "../../db/newCoins";

interface Props {
  onOpen: (open: boolean) => void;
  isOpen: boolean;
}

export const DiscoveryTable: FC<Props> = memo(({ onOpen, isOpen }) => {
  const coins = useAppSelector((state) => state.coins.coins);
  const coin = useAppSelector((state) => state.coin.coin);

  const [allPools, setAllPools] = useState<ICoinGeckoMarket[]>([
    ...coin,
    ...coins,
  ]);

  return (
    <div className="card overflow-hidden">
      <SimpleBar className="max-h-[704px]">
        <table className="min-w-[1517px] text-left text-sp">
          <thead className="font-medium text-cyan bg-dark-500 sticky top-0">
            <tr>
              <th scope="col" className="pl-10 py-6 w-1/5">
                <div className="flex gap-2">
                  NAME
                  <img
                    src={whiteSmallArrow}
                    alt="whiteSmallArrow"
                    className="flip cursor-pointer"
                    onClick={() => {
                      setAllPools(
                        [...allPools].sort((a, b) =>
                          a.name.localeCompare(b.name)
                        )
                      );
                    }}
                  />
                </div>
              </th>
              <th scope="col" className="py-6 w-1/6">
                <div className="flex gap-2">
                  PRICE
                  <img
                    src={whiteSmallArrow}
                    alt="whiteSmallArrow"
                    className="flip cursor-pointer"
                  />
                </div>
              </th>
              <th scope="col" className="py-6">
                <div className="flex gap-2 ml-14">
                  TRADING VOLUME (24H)
                  <img
                    src={whiteSmallArrow}
                    alt="whiteSmallArrow"
                    className="flip cursor-pointer"
                  />
                </div>
              </th>
              <th scope="col" className="py-6 w-1/5">
                <div className="flex gap-2">
                  MARKET CAP
                  <img
                    src={whiteSmallArrow}
                    alt="whiteSmallArrow"
                    className="flip cursor-pointer"
                  />
                </div>
              </th>
              <th scope="col" className="py-6">
                <div className="flex gap-2">ACTIONS</div>
              </th>
            </tr>
          </thead>
          <tbody className="[&>*:nth-child(even)]:bg-[#00000033] text-xs">
            {allPools.map((pool, i) => {
              const {
                image: icon,
                name: fullName,
                symbol: name,
                current_price: price,
                total_volume: tradingVolume,
                market_cap: marketCap,
              } = pool;
              return (
                <tr key={i} className="text-medium">
                  <td className="whitespace-nowrap pl-5 py-6">
                    <div className="flex items-center max-w-min gap-2">
                      <img src={icon} alt="icon" className="w-4" />

                      <div>{fullName}</div>

                      <div className="text-light-500">{name}</div>
                    </div>
                  </td>

                  <td className="whitespace-nowrap py-6 flex items-center">
                    ${numberWithCommas(price)}
                  </td>

                  <td className="whitespace-nowrap pl-14 py-6">
                    ${numberWithCommas(tradingVolume)}
                  </td>

                  <td className="whitespace-nowrap pr-5 py-6">
                    {numberWithCommas(marketCap)}
                  </td>

                  <td className="whitespace-nowrap pr-5 py-6">
                    <div
                      className="flex gap-2 scale-hover"
                      onClick={() => {
                        onOpen(!isOpen);
                      }}
                    >
                      <img
                        src={actionButton}
                        alt="actionButton"
                        className="cursor-pointer"
                      />
                      <img
                        src={actionsMoreButton}
                        alt="actionsMoreButton"
                        className="cursor-pointer"
                      />
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </SimpleBar>
    </div>
  );
});
