import { FC, memo, useEffect, useState } from "react";

import notificationBellBlack from "../../assets/icons/notificationBellBlack.svg";
import linkArrow from "../../assets/icons/linkArrow.svg";
import slowMist from "../../assets/icons/slowMist.svg";
import fairyproof from "../../assets/icons/fairyproof.svg";
import paper from "../../assets/icons/paper.svg";
import code from "../../assets/icons/code.svg";
import chat from "../../assets/icons/chat.svg";
import search from "../../assets/icons/search.svg";
import greenArrow from "../../assets/icons/greenArrow.svg";
import actionButton from "../../assets/icons/actionButton.svg";
import actionsMoreButton from "../../assets/icons/actionsMoreButton.svg";

import { Button } from "../../components/Button";
import classNames from "classnames";
import graySmallArrow from "../../assets/icons/graySmallArrow.svg";
import { DiscoveryTable } from "./DiscoverTable";
import { SwapChart } from "../Swap/components/SwapChart";
import { Menu, Tab } from "@headlessui/react";
import { discover } from "../../db/discover";
import { numberWithCommas } from "../helpers";
import SimpleBar from "simplebar-react";
import { tokens } from "../../db/tokens";
import { useAppSelector } from "../../store";
import { ChartDataItem } from "../../types/Currency";

const tableData = [
  {
    days: 1,
    label: "1D",
  },
  {
    days: 4,
    label: "1W",
  },
  {
    days: 24,
    label: "1M",
  },
  {
    days: 168,
    label: "3M",
  },
  {
    days: 720,
    label: "1Y",
  },
  {
    days: 3600,
    label: "YTD",
  },
  {
    days: 3601,
    label: "ALL",
  },
];

const chartData = [
  {
    days: 1,
    label: "1H",
  },
  {
    days: 4,
    label: "4H",
  },
  {
    days: 24,
    label: "1D",
  },
  {
    days: 168,
    label: "1W",
  },
  {
    days: 720,
    label: "1M",
  },
  {
    days: 3600,
    label: "6M",
  },
];

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function getRandomItemsFromArray(arr: any[]) {
  if (arr.length < 2) {
    throw new Error("Array must contain at least two elements");
  }

  const randomIndexes: number[] = [];
  while (randomIndexes.length < 2) {
    const randomIndex = Math.floor(Math.random() * arr.length);
    if (!randomIndexes.includes(randomIndex)) {
      randomIndexes.push(randomIndex);
    }
  }

  const randomItems = randomIndexes.map((index) => arr[index]);
  return randomItems;
}

export const Discover: FC = memo(() => {
  const { chartData: dataChart } = useAppSelector((state) => state.chart);

  const [currChartData, setCurrChartData] = useState<ChartDataItem[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [tableDataFilter, setTableDataFilter] = useState(tableData[2].days);
  const [chartDataFilter, setChartDataFilter] = useState(chartData[2].days);

  useEffect(() => {
    if (dataChart.prices.length > 1) {
      setCurrChartData(
        dataChart.prices.map((item: number[]) => ({
          time: item[0] / 1000,
          value: item[1],
          open: item[1],
          high: item[1],
          low: 0,
          close: 0,
        }))
      );
    }

    // eslint-disable-next-line
  }, [chartDataFilter, dataChart]);

  return (
    <div className="container px-4 my-7.5 sm:px-0">
      <div className="border-y border-dark-300 flex flex-wrap py-1.5 justify-between gap-2 items-center">
        <div className="text-sp">
          Here you can view tokens that are currently trending on Coingecko and
          Coinmarketcap
        </div>

        <div className="flex gap-7.5 items-center">
          <div className="flex flex-col text-[7px]">
            Tired of missing out on tokens that could be Trending Soon?
            <span className="font-medium">
              Subscribe now to receive email notifications!
            </span>
          </div>

          <Button height={24}>
            <div className="flex gap-1.25 items-center">
              <img src={notificationBellBlack} alt="notificationBellBlack" />{" "}
              Subscribe
            </div>
          </Button>
        </div>
      </div>

      <div className="mt-7.5">
        <DiscoveryTable isOpen={isOpen} onOpen={setIsOpen} />
      </div>

      <div className="py-7.5 flex justify-center sm:justify-between gap-4 items-center flex-wrap">
        <div className="flex gap-2.5 items-center font-medium">
          <span className="text-xs decoration-dashed underline">Timeframe</span>

          <div className="flex text-sp">
            {tableData.map(({ days, label }, i) => (
              <div
                key={i}
                onClick={() => setTableDataFilter(days)}
                className={classNames(
                  "rounded flex text-light-300 hover:bg-dark-100 items-center cursor-pointer justify-center h-5 px-1",
                  {
                    "gradient !text-dark-900": tableDataFilter === days,
                  }
                )}
              >
                {label}
              </div>
            ))}
          </div>
        </div>

        <div className="flex gap-3.5 text-light-500">
          <div className="relative">
            <Menu>
              {({ open }) => (
                <>
                  <Menu.Button
                    className={classNames(
                      "h-6 rounded-full bg-dark-300 whitespace-nowrap border border-transparent text-sp px-5 flex items-center gap-2",
                      { "!border-cyan text-white": open }
                    )}
                  >
                    All Chains
                    <img src={graySmallArrow} alt="graySmallArrow" />
                  </Menu.Button>

                  <Menu.Items className="absolute rounded text-s w-full overflow-hidden border border-primaryBorder mt-2.5  backdrop-blur-md z-10">
                    <SimpleBar className="max-h-[137px] text-white">
                      {tokens.map((token, i) => (
                        <Menu.Item key={i}>
                          {({ active }) => (
                            <div
                              className={classNames(
                                "py-1.25 px-2.5 cursor-pointer flex gap-1.25",
                                {
                                  "bg-cyan ": active,
                                }
                              )}
                            >
                              <img
                                src={token.icon}
                                alt="token"
                                className="w-3.25"
                              />
                              {token.fullName}
                            </div>
                          )}
                        </Menu.Item>
                      ))}
                    </SimpleBar>
                  </Menu.Items>
                </>
              )}
            </Menu>
          </div>

          <label className="h-6 rounded-full bg-dark-300 text-sp px-4 flex items-center gap-2">
            <input
              type="text"
              placeholder="Search by token name or tag"
              className="placeholder:text-light-500 bg-transparent focus:outline-none"
            ></input>

            <img src={search} alt="search" className="h-2.5" />
          </label>
        </div>
      </div>

      {isOpen && (
        <div className="card overflow-hidden">
          <div className="mt-7.5 mb-6 pl-5 flex text-sm text-light-300 items-end">
            <div className="w-[80px] text-center text-xl translate-x-1/2 sm:translate-x-0">
              $
            </div>

            <div className="grow flex justify-between flex-col lg:flex-row mx-7.5 items-center gap-2">
              <div className="rounded-lg bg-dark-900 flex flex-wrap justify-center gap-3 items-center py-4.5">
                <div className="px-1 lg:px-3 flex items-center gap-2">
                  <Tab.Group>
                    <Tab.List className="flex bg-dark-900 rounded-lg gap-2.5 text-sp">
                      <Tab
                        className={({ selected }) =>
                          classNames(
                            "border border-transparent py-1 rounded bg-dark-100 px-4.5",
                            {
                              "!border-cyan": selected,
                            }
                          )
                        }
                      >
                        Trading Volume
                      </Tab>
                      <Tab
                        className={({ selected }) =>
                          classNames(
                            "border border-transparent py-1 rounded bg-dark-100 px-4.5",
                            {
                              "!border-cyan": selected,
                            }
                          )
                        }
                      >
                        Price
                      </Tab>
                    </Tab.List>
                  </Tab.Group>
                </div>

                <div className="h-7	border-r hidden sm:block border-primaryBorder"></div>

                <div className="px-2 lg:px-5 text-2xl font-medium text-white">
                  $392,125
                </div>

                <div className="h-7	border-r hidden sm:block border-primaryBorder"></div>

                <div className="px-2 lg:px-5 text-end text-sm">
                  <div className="text-cyan">113,735 (40.85%)</div>
                  <div className="text-light-500">Past 24 hours</div>
                </div>

                <div className="relative text-xl">
                  <Menu>
                    <Menu.Button className="px-2 text-white bg-dark-100 rounded mr-4.5">
                      24h
                    </Menu.Button>
                    <Menu.Items className="flex flex-col text-center -translate-x-2 absolute w-full mt-2.5 card overflow-hidden z-10 text-xl">
                      <Menu.Item>
                        {({ active }) => (
                          <div
                            className={`${
                              active && "bg-cyan text-white  cursor-pointer"
                            } px-1`}
                          >
                            24h
                          </div>
                        )}
                      </Menu.Item>
                      <Menu.Item>
                        {({ active }) => (
                          <div
                            className={`${
                              active && "bg-cyan text-white cursor-pointer "
                            } px-1`}
                          >
                            1m
                          </div>
                        )}
                      </Menu.Item>
                      <Menu.Item>
                        {({ active }) => (
                          <div
                            className={`${
                              active && "bg-cyan text-white cursor-pointer "
                            } px-1`}
                          >
                            1y
                          </div>
                        )}
                      </Menu.Item>
                    </Menu.Items>
                  </Menu>
                </div>

                <div className="h-7	border-r hidden sm:block border-primaryBorder"></div>

                <div className="px-2 lg:px-5 font-medium text-light-500 text-sm">
                  <div className="">
                    Low: <span className="text-white">$0.08758</span>
                  </div>
                  <div className="">
                    High: <span className="text-white">$0.09517</span>
                  </div>
                </div>
              </div>

              <div className="rounded-lg bg-dark-900 flex h-[50px] p-1.25 text-xl">
                {chartData.map(({ days, label }, i) => (
                  <div
                    key={i}
                    onClick={() => setChartDataFilter(days)}
                    className={classNames(
                      "rounded-md flex items-center cursor-pointer hover:bg-dark-300 justify-center p-1.5",
                      {
                        "gradient text-dark-900": chartDataFilter === days,
                      }
                    )}
                  >
                    {label}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="relative pl-5">
            <SwapChart data={currChartData} />
          </div>

          <div className="my-7.5 flex flex-wrap gap-2 justify-between px-[25px] text-sp text-light-500">
            <div className="bg-dark-500 rounded-full px-3 h-6 flex items-center gap-2">
              <img src={slowMist} alt="slowMist" />
              SlowMist
              <img src={linkArrow} alt="linkArrow" />
            </div>

            <div className="bg-dark-500 rounded-full px-3 h-6 flex items-center gap-2">
              <img src={fairyproof} alt="fairyproof" />
              Fairyproof
              <img src={linkArrow} alt="linkArrow" />
            </div>

            <div className="bg-dark-500 rounded-full px-3 h-6 flex items-center gap-2">
              Whitepaper
              <img src={paper} alt="paper" />
            </div>

            <div className="bg-dark-500 rounded-full px-3 h-6 flex items-center gap-2">
              Source code
              <img src={code} alt="code" />
            </div>

            <div className="bg-dark-500 rounded-full px-3 h-6 flex items-center gap-2">
              Chat
              <img src={chat} alt="chat" />
            </div>

            <div className="bg-dark-500 rounded-full px-3 h-6 flex items-center gap-2">
              Explorers
              <img src={search} alt="search" className="w-2.5" />
            </div>

            <div className="bg-dark-500 rounded-full px-3 h-6 flex items-center gap-2">
              Web Site
              <img src={linkArrow} alt="linkArrow" />
            </div>

            <div className="relative">
              <Menu>
                <Menu.Button className="bg-dark-900 rounded px-3 h-6 flex items-center gap-2 relative text-cyan">
                  Community <img src={greenArrow} alt="greenArrow" />
                </Menu.Button>
                <Menu.Items className="absolute backdrop-blur-md z-10 card rounded flex flex-col text-light-500 right-0 mt-2.5 py-2">
                  <Menu.Item>
                    {({ active }) => (
                      <a
                        className={`${
                          active && "bg-cyan text-white"
                        } px-4.5 py-1.5 flex gap-1`}
                        href="https://www.facebook.com/"
                      >
                        Facebook <img src={linkArrow} alt="linkArrow" />
                      </a>
                    )}
                  </Menu.Item>
                  <Menu.Item>
                    {({ active }) => (
                      <a
                        className={`${
                          active && "bg-cyan text-white"
                        } px-4.5 py-1.5 flex gap-1`}
                        href="https://www.reddit.com/"
                      >
                        Reddit <img src={linkArrow} alt="linkArrow" />
                      </a>
                    )}
                  </Menu.Item>
                  <Menu.Item>
                    {({ active }) => (
                      <a
                        className={`${
                          active && "bg-cyan text-white"
                        } px-4.5 py-1.5 flex gap-1`}
                        href="https://twitter.com/home"
                      >
                        Twitter <img src={linkArrow} alt="linkArrow" />
                      </a>
                    )}
                  </Menu.Item>
                </Menu.Items>
              </Menu>
            </div>
          </div>

          <SimpleBar>
            <table className="min-w-[1517px] text-left text-sp">
              <tbody className="[&>*:nth-child(odd)]:bg-[#00000033] text-xs">
                {getRandomItemsFromArray(discover).map((item, i) => {
                  const {
                    icon,
                    fullName,
                    name,
                    price,
                    tradingVolume,
                    marketCap,
                    holders,
                  } = item;

                  return (
                    <tr key={i} className="text-medium">
                      <td className="whitespace-nowrap pl-5 py-6">
                        <div className="flex items-center max-w-min gap-2">
                          <img src={icon} alt="icon" className="w-4" />

                          <div>{fullName}</div>

                          <div className="text-light-500">{name}</div>
                        </div>
                      </td>
                      <td className="whitespace-nowrap py-6 flex items-center">
                        ${price}
                      </td>

                      <td className="whitespace-nowrap pl-14 py-6">
                        ${numberWithCommas(tradingVolume)}
                      </td>

                      <td className="whitespace-nowrap pr-5 py-6">
                        {typeof marketCap === "string"
                          ? marketCap
                          : numberWithCommas(marketCap)}
                      </td>

                      <td className="whitespace-nowrap pr-5 py-6">
                        {typeof holders === "string"
                          ? holders
                          : numberWithCommas(holders)}
                      </td>

                      <td className="whitespace-nowrap pr-5 py-6">
                        <div className="flex justify-end gap-2">
                          <img
                            src={actionButton}
                            alt="actionButton"
                            className="cursor-pointer"
                          />
                          <img
                            src={actionsMoreButton}
                            alt="actionsMoreButton"
                            className="cursor-pointer"
                          />
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </SimpleBar>
        </div>
      )}
    </div>
  );
});
