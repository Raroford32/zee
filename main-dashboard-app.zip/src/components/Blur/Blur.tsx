import { Transition } from '@headlessui/react';
import classNames from 'classnames';
import { FC, Fragment } from 'react';

interface Props {
  isOpen: boolean;
  isAllBlured?: boolean;
  indexNegative?: boolean;
}

export const Blur: FC<Props> = ({ isOpen, isAllBlured, indexNegative }) => {
  return (
    <Transition
      show={isOpen}
      as={Fragment}
      enter="ease-out duration-300"
      enterFrom="opacity-0"
      enterTo="opacity-100"
      leave="ease-in duration-200"
      leaveFrom="opacity-100"
      leaveTo="opacity-0">
      <div
        className={classNames(
          'fixed inset-0 top-[90px] backdrop-blur bg-dark-900 bg-opacity-70 z-20',
          { 'z-40': isAllBlured, '!-z-10': indexNegative }
        )}></div>
    </Transition>
  );
};
