import classNames from 'classnames';
import React, { FC, memo } from 'react';

export interface Props {
  height?: number | string;
  width?: number | string;
  variant?: string;
  className?: string;
  onClick?: (() => void) | ((e: React.MouseEvent<HTMLButtonElement>) => void);
  disable?: boolean;
  isSubmit?: boolean;
  isFull?: boolean;
}

export const Button: FC<React.PropsWithChildren<Props>> = memo(
  ({
    children,
    variant = 'default',
    height = 36,
    width,
    isFull = false,
    className = '',
    onClick,
    disable = false,
    isSubmit,
    ...otherProps
  }) => {
    const rootClassName = classNames(
      'rounded disabled:opacity-25 flex justify-center items-center font-bold text-xs text-black transition ease-out',
      {
        'w-full': isFull,
        'btn-primary px-4.5': variant === 'default',
        'bg-[#1E2044] border border-superLightBlueBorder font-Inter font-bold text-lightRed':
          variant === 'light',
        [className]: true
      }
    );

    return (
      <button
        type={isSubmit ? 'submit' : 'button'}
        disabled={disable}
        className={rootClassName}
        onClick={onClick}
        style={{ height, width }}
        {...otherProps}>
        {children}
      </button>
    );
  }
);
