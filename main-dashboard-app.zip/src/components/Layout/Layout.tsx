import { IsBulrVisible } from '../../context/context';
import { Blur } from '../Blur';
import { Footer } from './Footer';
import { Header } from './Header';
import { useContext } from 'react';

export const Layout: React.FC<React.PropsWithChildren> = ({ children }) => {
  const { isBlur } = useContext(IsBulrVisible);

  return (
    <div className="font-Ubuntu">
      <Header/>

      <Blur isOpen={isBlur} />

      <div className="container pb-22">
        {children}
      </div>

      <Footer />
    </div>
  );
};
