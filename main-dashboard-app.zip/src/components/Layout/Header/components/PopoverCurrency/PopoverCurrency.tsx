import { Popover } from '@headlessui/react';
import { FC, memo } from 'react';

import { PopoverCurrencyChild } from './PopoverCurrencyChild';

export const PopoverCurrency: FC = memo(() => {
  return (
    <Popover className="relative shrink-0">
      {({ open }) => {
        return <PopoverCurrencyChild open={open} />;
      }}
    </Popover>
  );
});
