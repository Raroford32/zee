import { FC, memo, useContext, useEffect, Fragment, useState } from 'react';
import { SelectedChainContext } from '../../../../../context/context';
import { Popover, Transition } from '@headlessui/react';
import classNames from 'classnames';

import smallArrow from '../../../../../assets/icons/smallArrow.svg';
import { chains } from '../../../../../db/chains';
import { Blur } from '../../../../Blur';

interface Props {
  open: boolean;
}

export const PopoverCurrencyChild: FC<Props> = memo(({ open }) => {
  const { selectedChain, setSelectedChain } = useContext(SelectedChainContext);
  const [isBlur, setIsBlur] = useState(false);

  useEffect(() => {
    setIsBlur(open);
  }, [open, setIsBlur]);

  return (
    <>
      <Blur isAllBlured={true} isOpen={isBlur} />

      <Popover.Button
        className={classNames(
          'border border-transparent flex items-center rounded text-sm h-11.5 px-4.5 btn-secondary',
          {
            '!border-cyanLight hover:bg-opacity-0': open
          }
        )}>
        <img src={selectedChain.logo} alt="" className="w-5" />

        <span className="ml-3 mr-[9px]">{selectedChain.name}</span>

        <img
          src={smallArrow}
          alt="smallArrow"
          className={classNames('transition', {
            'rotate-180': open
          })}
        />
      </Popover.Button>

      <Transition
        as={Fragment}
        enter="transition ease-out duration-200"
        enterFrom="opacity-0 translate-y-1"
        enterTo="opacity-100 translate-y-0"
        leave="transition ease-in duration-150"
        leaveFrom="opacity-100 translate-y-0"
        leaveTo="opacity-0 translate-y-1">
        <Popover.Panel className="absolute left-[153%] sm:left-full -translate-x-full z-40 mt-7.5 w-screen max-w-sm">
          <div className="overflow-hidden rounded-lg border border-primaryBorder bg-dark-200">
            <div className=" px-3.5 py-5">
              <div className="text-xs font-medium text-center">Select a Chain</div>

              <div className="grid grid-cols-3 mt-5 text-s">
                {chains.map((chain, i) => {
                  const { logo, name } = chain;
                  return (
                    <div
                      onClick={() => setSelectedChain(chain)}
                      className={classNames(
                        'p-1.25 flex items-center relative gap-1.25 border border-transparent hover:bg-dark-900 cursor-pointer',
                        {
                          'rounded !border-cyanLight bg-dark-900': selectedChain.name === name
                        }
                      )}
                      key={i}>
                      <img src={logo} alt="chain logo" />

                      {name}

                      {selectedChain.name === name && (
                        <span className="absolute right-1.25 rounded-full w-1.25 h-1.25 bg-cyanLight border border-[#305041]"></span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </Popover.Panel>
      </Transition>
    </>
  );
});
