import { FC, memo, useState } from 'react';

import UKflag from '../../../../../assets/icons/UKflag.svg';
import PLflag from '../../../../../assets/icons/PLflag.svg';
import DEflag from '../../../../../assets/icons/DEflag.svg';

import classNames from 'classnames';

export const LanguagePicker: FC = memo(() => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="h-6 w-6 relative shrink-0">
      <div
        onClick={() => setIsOpen(!isOpen)}
        className={classNames(
          'gradient rounded-full p-0.5 transition-all absolute flex flex-col gap-2 overflow-hidden',
          {
            'max-h-full p-[1px]': !isOpen
          }
        )}>
        <img src={UKflag} alt="uk flag" className="cursor-pointer scale-hover" />
        <img src={PLflag} alt="pl flag" className="cursor-pointer scale-hover" />
        <img src={DEflag} alt="de flag" className="cursor-pointer scale-hover" />
      </div>
    </div>
  );
});
