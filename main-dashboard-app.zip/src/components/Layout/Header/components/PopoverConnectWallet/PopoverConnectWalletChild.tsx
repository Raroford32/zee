import { FC, memo, useEffect, Fragment, useState } from 'react';
import { Popover, Tab, Transition } from '@headlessui/react';

import { Blur } from '../../../../Blur';

import settings from '../../../../../assets/icons/settings.svg';
import profileIcon from '../../../../../assets/icons/profileIcon.svg';
import info from '../../../../../assets/icons/info.svg';
import classNames from 'classnames';

interface Props {
  open: boolean;
}

export const PopoverConnectWalletChild: FC<Props> = memo(({ open }) => {
  const [isBlur, setIsBlur] = useState(false);

  useEffect(() => {
    setIsBlur(open);
  }, [open, setIsBlur]);

  return (
    <>
      <Blur isAllBlured={true} isOpen={isBlur} />

      <Popover.Button className="flex rounded disabled:opacity-25 h-9 justify-center items-center font-bold text-xs text-black btn-primary px-1 lg:px-4.5">
        CONNECT WALLET
      </Popover.Button>

      <Transition
        as={Fragment}
        enter="transition ease-out duration-200"
        enterFrom="opacity-0 translate-y-1"
        enterTo="opacity-100 translate-y-0"
        leave="transition ease-in duration-150"
        leaveFrom="opacity-100 translate-y-0"
        leaveTo="opacity-0 translate-y-1">
        <Popover.Panel className="absolute left-1/2 sm:left-full -translate-x-1/2 sm:-translate-x-full z-40 mt-0` sm:mt-8 text-xs">
          <div className="overflow-hidden rounded-lg border border-primaryBorder w-[276px] bg-dark-200 py-5">
            <div className="mx-5 ">
              Your Account
              <div className="mt-5 bg-dark-900 rounded-xl flex flex-col justify-between p-2.5 h-[119px]">
                <div className="flex justify-between">
                  <div className="flex gap-3 items-center text-sm">
                    <img src={profileIcon} alt="profileIcon" />
                    0xf616...7F7e
                  </div>

                  <img src={settings} alt="settings" />
                </div>

                <div className="text-sp">
                  Total Balance
                  <div className="text-base">$4.88238551</div>
                </div>
              </div>
              <Tab.Group>
                <Tab.List className="mt-2.5 flex justify-between text-sp">
                  <Tab
                    className={({ selected }) =>
                      classNames(
                        'border border-transparent w-[70px] h-[27px] bg-dark-900 rounded',
                        { '!border-cyan': selected }
                      )
                    }>
                    Buy
                  </Tab>
                  <Tab
                    className={({ selected }) =>
                      classNames(
                        'border border-transparent w-[70px] h-[27px] bg-dark-900 rounded',
                        { '!border-cyan': selected }
                      )
                    }>
                    Swap
                  </Tab>
                  <Tab
                    className={({ selected }) =>
                      classNames(
                        'border border-transparent w-[70px] h-[27px] bg-dark-900 rounded',
                        { '!border-cyan': selected }
                      )
                    }>
                    Send
                  </Tab>
                </Tab.List>
              </Tab.Group>

              <div className="mt-3.25"><span className='text-cyan'>Assets</span> Transactions</div>
            </div>

            <div className="border-y border-primaryBorder h-[53px] mt-2.5"></div>

            <div className="flex flex-col justify-center text-center gap-2.5 mt-2.5 text-sp">
              <img src={info} alt="info" className='w-5 ml-auto mr-auto' />

              <div className="text-light-300">Don’t see your tokens <div className="text-cyan">Import Tokens</div></div>
            </div>
          </div>
        </Popover.Panel>
      </Transition>
    </>
  );
});
