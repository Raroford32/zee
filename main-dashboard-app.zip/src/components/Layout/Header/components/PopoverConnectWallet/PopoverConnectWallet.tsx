import { Popover } from '@headlessui/react';
import { FC, memo } from 'react';

import { PopoverConnectWalletChild } from './PopoverConnectWalletChild';
import classNames from 'classnames';

interface Props {
  isSmallVersion?: boolean;
}

export const PopoverConnectWallet: FC<Props> = memo(({ isSmallVersion = false }) => {
  return (
    <Popover
      className={classNames({
        'relative shrink-0': isSmallVersion,
        'relative shrink-0 hidden md:block': !isSmallVersion
      })}>
      {({ open }) => {
        return <PopoverConnectWalletChild open={open} />;
      }}
    </Popover>
  );
});
