import { Popover, Tab, Transition } from '@headlessui/react';
import { FC, Fragment, useEffect, memo, useState } from 'react';

import SimpleBarReact from 'simplebar-react';

import notificationBell from './../../../../../assets/icons/notificationBell.svg';
import { notifications } from '../../../../../db/notifications';
import classNames from 'classnames';
import { Blur } from '../../../../Blur';

interface Props {
  open: boolean;
}

export const PopoverNotificationsChild: FC<Props> = memo(({ open }) => {
  const myBoxNotifications = notifications.slice(
    notifications.length - notifications.length / 2,
    notifications.length
  );

  const [isBlur, setIsBlur] = useState(false);

  useEffect(() => {
    setIsBlur(open);
  }, [open, setIsBlur]);

  return (
    <>
     <Blur isAllBlured={true} isOpen={isBlur} />

      <Popover.Button>
        <div className="flex items-center cursor-pointer scale-hover relative">
          <img src={notificationBell} alt="notificationBell" />

          <div className="absolute bg-bloodRed w-[9px] h-[9px] -right-0.5 top-0 rounded-full flex justify-center items-center">
            <span className="text-[6px] font-bold">1</span>
          </div>
        </div>
      </Popover.Button>

      <Transition
        as={Fragment}
        enter="transition ease-out duration-200"
        enterFrom="opacity-0 translate-y-1"
        enterTo="opacity-100 translate-y-0"
        leave="transition ease-in duration-150"
        leaveFrom="opacity-100 translate-y-0"
        leaveTo="opacity-0 translate-y-1">
        <Popover.Panel className="absolute left-full -translate-x-full z-40 mt-[60px] w-screen max-w-[190px]">
          <Tab.Group>
            <div className="overflow-hidden rounded-lg border border-primaryBorder">
              <div className=" pt-5.25 px-4.5 pb-2.5 flex flex-col text-center gap-3.5 bg-dark-300">
                <div className="text-xs font-medium">Notifications</div>

                <Tab.List className="w-full bg-dark-900 rounded-sm text-smaller p-0.5 flex font-medium text-light-300">
                  <Tab
                    className={({ selected }) =>
                      classNames('h-3 flex-grow rounded-sm', {
                        'bg-cyan text-black': selected
                      })
                    }>
                    My Inbox
                  </Tab>
                  <Tab
                    className={({ selected }) =>
                      classNames('h-3 flex-grow rounded-sm', {
                        'bg-cyan text-black': selected
                      })
                    }>
                    General
                  </Tab>
                </Tab.List>
              </div>

              <Tab.Panels className="text-s bg-dark-900">
                <Tab.Panel>
                  <SimpleBarReact style={{ maxHeight: 255 }}>
                    {notifications.map((item, i) => {
                      const { img, title, description, time } = item;
                      return (
                        <div
                          key={i}
                          className="flex gap-2.5 px-2.5 py-1.5 items-center border-t border-primaryBorder">
                          <img src={img} alt="notification img" />

                          <div>
                            <div className="text-smaller font-medium">{title}</div>

                            <div className="text-[8px] text-light-500">{description}</div>

                            <div className="flex justify-end text-light-500 text-[4px]">{time}</div>
                          </div>
                        </div>
                      );
                    })}
                  </SimpleBarReact>
                </Tab.Panel>

                <Tab.Panel>
                  <SimpleBarReact style={{ maxHeight: 255 }}>
                    {myBoxNotifications.map((item, i) => {
                      const { img, title, description, time } = item;
                      return (
                        <div
                          key={i}
                          className="flex gap-2.5 px-2.5 py-1.5 items-center border-t border-primaryBorder">
                          <img src={img} alt="notification img" />

                          <div className="">
                            <div className="text-smaller font-medium">{title}</div>

                            <div className="text-[8px] text-light-500">{description}</div>

                            <div className="flex justify-end text-light-500 text-[4px]">{time}</div>
                          </div>
                        </div>
                      );
                    })}
                  </SimpleBarReact>
                </Tab.Panel>
              </Tab.Panels>
            </div>
          </Tab.Group>
        </Popover.Panel>
      </Transition>
    </>
  );
});
