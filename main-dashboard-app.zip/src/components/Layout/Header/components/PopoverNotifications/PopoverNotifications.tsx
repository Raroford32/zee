/* eslint-disable @typescript-eslint/no-unused-vars */
import { Popover } from '@headlessui/react';
import { FC, memo } from 'react';
import { PopoverNotificationsChild } from './PopoverNotificationsChild';


export const PopoverNotifications: FC = memo(() => {

  return (
    <Popover className="relative flex shrink-0">
      {({ open }) => {
        return (
         <PopoverNotificationsChild open={open} />
        );
      }}
    </Popover>
  );
});
