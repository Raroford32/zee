import { Link, useLocation } from "react-router-dom";

import logo from "./../../../assets/logo.svg";

import { useState } from "react";
import classnames from "classnames";
import { FC, memo } from "react";

import { LanguagePicker } from "./components/LanguagePicker";
import { PopoverCurrency } from "./components/PopoverCurrency";
import { PopoverNotifications } from "./components/PopoverNotifications";
import arrow from "../../../assets/icons/graySmallArrow.svg";
import classNames from "classnames";
import { PopoverConnectWallet } from "./components/PopoverConnectWallet";

const screens = [
  {
    label: "Swap",
    url: "Swap",
  },
  {
    label: "Liquidity",
    url: "Liquidity",
  },
  {
    label: "Discover",
    url: "Discover",
  },
  {
    label: "About",
    url: "About",
  },
];

export const Header: FC = memo(() => {
  const [isOpen, setIsOpen] = useState(false);

  const { pathname } = useLocation();

  return (
    <header className=" sticky top-0 z-50">
      <div
        className={classNames("h-16 bg-dark-300 lg:h-22 transition-all", {
          "h-48": isOpen,
        })}
      >
        <div className="flex flex-col justify-between h-full">
          <div className="container px-3 flex gap-3 h-full justify-between items-center">
            <div className="flex gap-5 text-title font-OpenSans grow">
              <img src={logo} alt="logo" className="h-10 lg:h-full" />

              <h1 className="hidden lg:block">Zeedex</h1>
            </div>

            <ul className="hidden md:flex gap-1 p-[5px] font-medium text-sm bg-dark-900 rounded">
              {screens.map(({ label, url }) => (
                <Link key={label} to={url}>
                  <li
                    key={url}
                    className={classnames(
                      "rounded h-9 flex items-center px-4.5 btn-secondary",
                      {
                        "btn-primary": pathname.includes(url),
                      }
                    )}
                  >
                    {label}
                  </li>
                </Link>
              ))}
            </ul>

            <div className="flex gap-3 xl:gap-6 items-center justify-end grow">
              <PopoverCurrency />

              <PopoverConnectWallet />

              <PopoverNotifications />

              <LanguagePicker />
            </div>
          </div>

          <div
            className={classNames(
              "text-sm flex h-full flex-col gap-1.5 items-center transition-all",
              {
                "!h-0 overflow-hidden": !isOpen,
              }
            )}
          >
            <PopoverConnectWallet isSmallVersion={true} />

            <ul className="flex p-[5px] font-medium text-sm bg-dark-900 rounded">
              {screens.map(({ label, url }) => (
                <Link className="scale-hover" key={label} to={url}>
                  <li
                    key={url}
                    className={classnames(
                      "rounded h-9 flex items-center px-4.5",
                      {
                        "btn-primary": pathname.includes(url),
                      }
                    )}
                  >
                    {label}
                  </li>
                </Link>
              ))}
            </ul>
          </div>
        </div>
      </div>

      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex cursor-pointer ml-auto mr-auto justify-center items-center md:hidden w-10 h-3 bg-dark-300 border-b border-x rounded-b-lg border-primaryBorder"
      >
        <img
          src={arrow}
          alt="arrow"
          className={classNames("transition rotate-0", {
            "!rotate-180": isOpen,
          })}
        />
      </button>
    </header>
  );
});
