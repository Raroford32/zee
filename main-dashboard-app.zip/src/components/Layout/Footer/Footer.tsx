import telegram from '../../../assets/icons/socials/telegram.svg';
import twitter from '../../../assets/icons/socials/twitter.svg';
import discord from '../../../assets/icons/socials/discord.svg';
import mLogo from '../../../assets/icons/socials/mLogo.svg';
import arrow from '../../../assets/icons/graySmallArrow.svg';

import { FC, memo, useState } from 'react';
import classNames from 'classnames';

const socials = [
  {
    icon: telegram,
    url: 'https://telegram.org/'
  },
  {
    icon: twitter,
    url: 'https://twitter.com/home'
  },
  {
    icon: discord,
    url: 'https://discord.com/'
  },
  {
    icon: mLogo,
    url: ''
  }
];

export const Footer: FC = memo(() => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <footer className="fixed bottom-0 w-full bg-dark-300 px-2 pb-2 z-50">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex cursor-pointer ml-auto mr-auto justify-center items-center md:hidden w-10 h-3 bg-dark-300 border-t border-x rounded-t-lg border-primaryBorder -translate-y-full">
        <img
          src={arrow}
          alt="arrow"
          className={classNames('transition rotate-180', {
            '!rotate-0': isOpen
          })}
        />
      </button>

      <div
        className={classNames('h-16 lg:h-22 transition-all', {
          'h-32': isOpen
        })}>
        <div className="flex justify-between flex-col h-full">
          <div
            className={classNames(
              'text-sm flex h-full justify-between mx-4 items-center transition-all overflow-hidden',
              {
                '!h-0': !isOpen
              }
            )}>
            <a href="" className='scale-hover'>Affiliate</a>
            <a href="" className='scale-hover'>Regulations </a>
            <a href="" className='scale-hover'>Terms</a>
            <a href="" className='scale-hover'>FAQ</a>
            <a href="" className='scale-hover'>Docs</a>
            <a href="" className='scale-hover'>Contacts</a>
          </div>

          <div className="container flex justify-between items-center h-full">
            <div className="text-light-400 text-sm">2024 © Zeedex.io</div>

            <div className="gap-5 text-base hidden md:flex">
              <a href="" className='scale-hover'>Affiliate</a>
              <a href="" className='scale-hover'>Regulations </a>
              <a href="" className='scale-hover'>Terms</a>
              <a href="" className='scale-hover'>FAQ</a>
              <a href="" className='scale-hover'>Docs</a>
              <a href="" className='scale-hover'>Contacts</a>
            </div>

            <div className="flex gap-6 items-center">
              {socials.map(({ icon, url }) => (
                <a href={url} key={url}>
                  <img src={icon} alt="social link" />
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
});
