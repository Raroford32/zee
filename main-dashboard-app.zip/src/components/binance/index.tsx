import React, { useState, useEffect } from 'react';

interface BinanceData {
  symbol: string;
  price: string;
}

const BinanceDataComponent: React.FC = () => {
  const [binanceData, setBinanceData] = useState<BinanceData[] | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('https://api.binance.com/api/v3/ticker/price');
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const data: BinanceData[] = await response.json();
        setBinanceData(data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <div>
      <h2>Binance Data</h2>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <ul>
          {binanceData?.map((item, index) => (
            <li key={index}>
              Symbol: {item.symbol}, Price: {item.price}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default BinanceDataComponent;
