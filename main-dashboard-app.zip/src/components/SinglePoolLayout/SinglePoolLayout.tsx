import React, { FC } from 'react';
import leftWhiteArrow from '../../assets/icons/leftWhiteArrow.svg';
import { Link, NavLink, useLocation } from 'react-router-dom';
import classNames from 'classnames';

const poolOptions = [
  {
    label: 'Overview',
    url: 'overview'
  },
  {
    label: 'My Positions',
    url: 'positions'
  },
  {
    label: 'Deposit',
    url: 'deposit'
  },
  {
    label: 'Withdraw',
    url: 'withdraw'
  }
];

export const SinglePoolLayout: FC<React.PropsWithChildren> = ({ children }) => {
  const { pathname } = useLocation();

  return (
    <div className="mt-7.5 lg:mt-[60px] mb-7.5 flex flex-col lg:flex-row">
      <div className="flex flex-row flex-wrap items-center lg:items-start justify-center lg:justify-start lg:flex-col gap-3">
        <Link to={'/Liquidity'} className="flex gap-2.5 cursor-pointer">
          <img src={leftWhiteArrow} alt="leftWhiteArrow" />
          Pools
        </Link>

        <div className="flex flex-row lg:flex-col flex-wrap">
          {poolOptions.map(({ label, url }) => (
            <NavLink
              key={url}
              to={pathname.split('/').slice(0, -1).join('/') + '/' + url}
              className={({ isActive }) =>
                classNames(
                  'flex justify-between transition gap-1.5 h-7.5 cursor-pointer text-light-500 rounded pl-3.5 overflow-hidden',
                  {
                    'bg-dark-300 text-white': isActive,
                    'hover:bg-dark-100': !isActive
                  }
                )
              }>
              {label}

              <div
                className={classNames('bg-cyan w-1.25 h-full opacity-0', {
                  'opacity-100': pathname.includes(url)
                })}></div>
            </NavLink>
          ))}
        </div>
      </div>

      <div className="lg:ml-[84px] mt-5 lg:mt-0 grow px-4 sm:p-0">{children}</div>
    </div>
  );
};
