import React, { useState, useEffect } from "react";
import axios from "axios";
import { TrendingCoins } from "../../config/api";

interface Currency {
  id: string;
  name: string;
  symbol: string;
}

const CurrencyList: React.FC = () => {
  const [currencies, setCurrencies] = useState<Currency[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(TrendingCoins("usd"));
        setCurrencies(response.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  return (
    <div>
      <h2>Currencies</h2>
      <ul>
        {currencies.map((currency) => (
          <li key={currency.id}>
            {currency.name} ({currency.symbol})
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CurrencyList;
