import { FC, memo, useState } from 'react';
import { Switch } from '@headlessui/react';

interface Props {
  isReversed?: boolean
}

export const SwitchItem: FC<Props> = memo(({isReversed = false}) => {
  const [isAdvancedMode, setIsAdvancedMode] = useState(isReversed);

  return (
    <Switch
      checked={isAdvancedMode}
      onChange={setIsAdvancedMode}
      className={`${
        isAdvancedMode ? 'bg-cyanSuperDark' : 'bg-dark-100'
      } relative inline-flex h-3 w-7 items-center rounded-full`}>
      <span className="sr-only">Enable notifications</span>
      <span
        className={`${
          isAdvancedMode ? 'translate-x-[17px] bg-cyan' : 'translate-x-px bg-light-300'
        } inline-block h-2.5 w-2.5 transform rounded-full  transition`}
      />
    </Switch>
  );
});
