export interface Pool {
  id: number;
  fromName: string;
  fromIcon: string;
  toName: string;
  toIcon: string;
  type: string;
  liquidity: number;
  APR: number;
}
