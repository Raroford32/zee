import { Routes } from 'react-router-dom';
import { DashBoardRoutes } from './routes/routeConfig';
import { useState } from 'react';
import { SelectedChainContext, IsBulrVisible } from './context/context';
import { chains } from './db/chains';

import 'simplebar-react/dist/simplebar.min.css';

function App() {
  const [selectedChain, setSelectedChain] = useState(chains[0]);
  const [isBlur, setIsBlur] = useState(false);

  return (
    <IsBulrVisible.Provider value={{ isBlur, setIsBlur }}>
      <SelectedChainContext.Provider value={{ selectedChain, setSelectedChain }}>
        <Routes>{DashBoardRoutes()}</Routes>
      </SelectedChainContext.Provider>
    </IsBulrVisible.Provider>
  );
}

export default App;
