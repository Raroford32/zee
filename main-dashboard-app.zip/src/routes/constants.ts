export const ADMIN_ROOT = '/';
export const SWAP = '/Swap';
export const LIQUIDITY = '/Liquidity';
export const DISCOVER = '/Discover';
export const ABOUT = '/About';
export const POOL_OVERVIEW = `${LIQUIDITY}/:id/Overview`;
export const POOL_POSITIONS = `${LIQUIDITY}/:id/Positions`;
export const POOL_DEPOSIT = `${LIQUIDITY}/:id/Deposit`;
export const POOL_WITHDRAW = `${LIQUIDITY}/:id/Withdraw`;

export const ADMIN = {
  PATHS: {
    ROOT: ADMIN_ROOT
  }
};
