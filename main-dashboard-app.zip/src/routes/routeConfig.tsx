import { Route, Outlet } from 'react-router-dom';

import { Layout } from '../components/Layout';
import {
  ADMIN,
  SWAP,
  LIQUIDITY,
  DISCOVER,
  ABOUT,
  POOL_OVERVIEW,
  POOL_POSITIONS,
  POOL_DEPOSIT,
  POOL_WITHDRAW
} from './constants';

import { Swap } from '../features/Swap';
import { Liquidity } from '../features/Liquidity';
import { Discover } from '../features/Discover';
import { About } from '../features/About';
import { SinglePoolLayout } from '../components/SinglePoolLayout';
import { PoolOverview } from '../features/Liquidity/components/PoolOverview';
import { PoolPositions } from '../features/Liquidity/components/PoolPositions';
import { PoolDeposit } from '../features/Liquidity/components/PoolDeposit';
import { PoolWithdraw } from '../features/Liquidity/components/PoolWithdraw';

export const DashBoardLayout: React.FC = () => {
  return (
    <Layout>
      <Outlet />
    </Layout>
  );
};

export const SinglePool: React.FC = () => {
  return (
    <SinglePoolLayout>
      <Outlet />
    </SinglePoolLayout>
  );
};

export const DashBoardRoutes = (): JSX.Element => {
  return (
    <Route path={ADMIN.PATHS.ROOT} element={<DashBoardLayout />}>
      <Route path="*" element={<div>Not found 404</div>} />

      <Route index path={SWAP} element={<Swap />} />
      <Route index element={<Swap />} />
      <Route path={LIQUIDITY} element={<Liquidity />} />
      <Route path={`${LIQUIDITY}/:id`} element={<SinglePool />}>
        <Route path={POOL_OVERVIEW} element={<PoolOverview />} />
        <Route path={POOL_POSITIONS} element={<PoolPositions />} />
        <Route path={POOL_DEPOSIT} element={<PoolDeposit />} />
        <Route path={POOL_WITHDRAW} element={<PoolWithdraw />} />
      </Route>
      <Route path={DISCOVER} element={<Discover />} />
      <Route path={ABOUT} element={<About />} />
    </Route>
  );
};
