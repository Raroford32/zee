import { createContext } from 'react';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const SelectedChainContext = createContext<any>({});
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const IsBulrVisible = createContext<any>({});
