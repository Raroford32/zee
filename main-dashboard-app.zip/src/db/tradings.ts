import FLOKI from '../assets/icons/cryptocurrenciesIcons/FLOKI.svg';
import LINA from '../assets/icons/cryptocurrenciesIcons/LINA.svg';
import WOO from '../assets/icons/cryptocurrenciesIcons/WOO.svg';
import ZRX from '../assets/icons/cryptocurrenciesIcons/ZRX.svg';

export const tradings = [
  {
    logo: FLOKI,
    name: 'FLOKI',
    price: 0.34,
    percent: 19
  },
  {
    logo: LINA,
    name: 'LINA',
    price: 0.0142,
    percent: 18
  },
  {
    logo: WOO,
    name: 'WOO',
    price: 0.0001,
    percent: 0
  },
  {
    logo: ZRX,
    name: 'ZRX',
    price: 0.22,
    percent: 7
  },
  {
    logo: WOO,
    name: 'WOO',
    price: 0.0001,
    percent: 0
  },
  {
    logo: ZRX,
    name: 'ZRX',
    price: 0.22,
    percent: 7
  },
  {
    logo: WOO,
    name: 'WOO',
    price: 0.0001,
    percent: 0
  },
  {
    logo: ZRX,
    name: 'ZRX',
    price: 0.22,
    percent: 7
  }
];
