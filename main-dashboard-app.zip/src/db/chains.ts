import Arbitrum from '../assets/icons/chains/Arbitrum.svg';
import Aurora from '../assets/icons/chains/Aurora.svg';
import Avax from '../assets/icons/chains/Avax.svg';
import BNB from '../assets/icons/chains/BNB.svg';
import BitTorrent from '../assets/icons/chains/BitTorrent.svg';
import Cronos from '../assets/icons/chains/Cronos.svg';
import ETH from '../assets/icons/chains/ETH.svg';
import Fantom from '../assets/icons/chains/Fantom.svg';
import Oasis from '../assets/icons/chains/Oasis.svg';
import Optimism from '../assets/icons/chains/Optimism.svg';
import Polygon from '../assets/icons/chains/Polygon.svg';
import Solana from '../assets/icons/chains/Solana.svg';
import Velas from '../assets/icons/chains/Velas.svg';

export const chains = [
  {
    logo: Arbitrum,
    name: 'Arbitrum'
  },
  {
    logo: Aurora,
    name: 'Aurora'
  },
  {
    logo: Avax,
    name: 'Avalanche'
  },
  {
    logo: BNB,
    name: 'BNB Chain'
  },
  {
    logo: BitTorrent,
    name: 'BitTorrent'
  },
  {
    logo: Cronos,
    name: 'Cronos'
  },
  {
    logo: ETH,
    name: 'Ethereum'
  },
  {
    logo: Fantom,
    name: 'Fantom'
  },
  {
    logo: Oasis,
    name: 'Oasis'
  },
  {
    logo: Optimism,
    name: 'Optimism'
  },
  {
    logo: Polygon,
    name: 'Polygon'
  },
  {
    logo: Solana,
    name: 'Solana'
  },
  {
    logo: Velas,
    name: 'Velas'
  }
];
