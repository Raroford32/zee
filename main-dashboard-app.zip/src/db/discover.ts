// import Cronos from "../assets/icons/chains/Cronos.svg";
// import Optimism from "../assets/icons/chains/Optimism.svg";
// import Aurora from "../assets/icons/chains/Aurora.svg";
// import Velas from "../assets/icons/chains/Velas.svg";
// import bitDAO from "../assets/icons/chains/bitDAO.svg";
// import tomiNet from "../assets/icons/chains/tomiNet.svg";
import Arbitrum from "../assets/icons/chains/Arbitrum.svg";
import Avax from "../assets/icons/chains/Avax.svg";
import BitTorrent from "../assets/icons/chains/BitTorrent.svg";
import FLOKICEO from "../assets/icons/chains/FLOKICEO.svg";
import Fantom from "../assets/icons/chains/Fantom.svg";
import GateToken from "../assets/icons/chains/GateToken.svg";
import Injective from "../assets/icons/chains/Injective.svg";
import Oasis from "../assets/icons/chains/Oasis.svg";
import Polygon from "../assets/icons/chains/Polygon.svg";
import Solana from "../assets/icons/chains/Solana.svg";
import polkadot from "../assets/icons/chains/polkadot.svg";

export const discover = [
  {
    icon: Arbitrum,
    fullName: "Zeedex",
    name: "ZDEX",
    price: "0.00",
    tradingVolume: 10497533,
    marketCap: "- -",
    holders: 19888,
  },
  {
    icon: Arbitrum,
    fullName: "Arbitrum",
    name: "ARB",
    price: "0.00",
    tradingVolume: 10497533,
    marketCap: "- -",
    holders: 19888,
  },
  {
    icon: Avax,
    fullName: "Avalanche",
    name: "AVAX",
    price: "0.00",
    tradingVolume: 123456789,
    marketCap: 567890123,
    holders: 65432,
  },
  {
    icon: BitTorrent,
    fullName: "BitTorrent",
    name: "BTT",
    price: "0.00",
    tradingVolume: 98765432,
    marketCap: 876543210,
    holders: 123456,
  },
  {
    icon: FLOKICEO,
    fullName: "FLOKICEO",
    name: "FLOKI",
    price: "0.00",
    tradingVolume: 56789012,
    marketCap: 345678901,
    holders: 4321,
  },
  {
    icon: Fantom,
    fullName: "Fantom",
    name: "FTM",
    price: "0.00",
    tradingVolume: 23456789,
    marketCap: 123456789,
    holders: 9876,
  },
  {
    icon: GateToken,
    fullName: "GateToken",
    name: "GTO",
    price: "0.00",
    tradingVolume: 45678901,
    marketCap: 2345678901,
    holders: 8765,
  },
  {
    icon: Injective,
    fullName: "Injective Protocol",
    name: "INJ",
    price: "0.00",
    tradingVolume: 12345678,
    marketCap: 2345678910,
    holders: 5432,
  },
  {
    icon: Oasis,
    fullName: "Oasis Network",
    name: "ROSE",
    price: "0.00",
    tradingVolume: 3456789,
    marketCap: 456789012,
    holders: 6789,
  },
  {
    icon: Polygon,
    fullName: "Polygon",
    name: "MATIC",
    price: "0.00",
    tradingVolume: 4567890,
    marketCap: 12345678901,
    holders: 7890,
  },
  {
    icon: Solana,
    fullName: "Solana",
    name: "SOL",
    price: "0.00",
    tradingVolume: 567890,
    marketCap: 23456789012,
    holders: 1234,
  },
  {
    icon: polkadot,
    fullName: "Polkadot",
    name: "DOT",
    price: "0.00",
    tradingVolume: 12345,
    marketCap: 567890123456,
    holders: 456,
  },
];
