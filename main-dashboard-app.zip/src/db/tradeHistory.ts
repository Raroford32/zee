export const tradesHistory = [
  {
    account: '0x17d4****f0dD',
    height: '8,912,938',
    hash: '0x3f5CE5F****E9af3971',
    inToken: 'BUSD',
    inAmount: '5',
    outToken: 'USDT',
    outAmount: 4.9986569595664,
    age: '14d 19h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '8,908,503',
    hash: '0x1f2CE5F****E9af1971',
    inToken: 'UNI',
    inAmount: '1',
    outToken: 'DOGE',
    outAmount: 90.32840625,
    age: '16d 22h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '11,108,503',
    hash: '0x6f8CE2F****E9af1971',
    inToken: 'BUSD',
    inAmount: '22',
    outToken: 'UNI',
    outAmount: 1.03567263940143,
    age: '18d 9h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '9,512,738',
    hash: '0x8a7CE9B****F5dD2841',
    inToken: 'ETH',
    inAmount: '2.5',
    outToken: 'LINK',
    outAmount: 80.67321976,
    age: '12d 14h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '10,213,909',
    hash: '0x2e4CE1D****C6fE4723',
    inToken: 'DAI',
    inAmount: '15',
    outToken: 'USDC',
    outAmount: 14.998763,
    age: '10d 6h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '7,321,504',
    hash: '0x9b3DE7A****D8eB8132',
    inToken: 'BTC',
    inAmount: '0.1',
    outToken: 'ETH',
    outAmount: 2.86542901,
    age: '20d 3h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '12,345,678',
    hash: '0x4c6FA8E****A1bC6405',
    inToken: 'LINK',
    inAmount: '10',
    outToken: 'AAVE',
    outAmount: 5.98765432,
    age: '9d 8h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '9,512,738',
    hash: '0x8a7CE9B****F5dD2841',
    inToken: 'ETH',
    inAmount: '2.5',
    outToken: 'LINK',
    outAmount: 80.67321976,
    age: '12d 14h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '10,213,909',
    hash: '0x2e4CE1D****C6fE4723',
    inToken: 'DAI',
    inAmount: '15',
    outToken: 'USDC',
    outAmount: 14.998763,
    age: '10d 6h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '7,321,504',
    hash: '0x9b3DE7A****D8eB8132',
    inToken: 'BTC',
    inAmount: '0.1',
    outToken: 'ETH',
    outAmount: 2.86542901,
    age: '20d 3h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '12,345,678',
    hash: '0x4c6FA8E****A1bC6405',
    inToken: 'LINK',
    inAmount: '10',
    outToken: 'AAVE',
    outAmount: 5.98765432,
    age: '9d 8h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '13,876,543',
    hash: '0x3b2DE3C****F7dA2819',
    inToken: 'USDC',
    inAmount: '100',
    outToken: 'BTC',
    outAmount: 0.03215678,
    age: '5d 17h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '14,567,890',
    hash: '0x1e9CB4F****B8cD9726',
    inToken: 'AAVE',
    inAmount: '3',
    outToken: 'ETH',
    outAmount: 89.7654321,
    age: '7d 21h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '11,108,503',
    hash: '0x6f8CE2F****E9af1971',
    inToken: 'BUSD',
    inAmount: '22',
    outToken: 'UNI',
    outAmount: 1.03567263940143,
    age: '18d 9h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '9,512,738',
    hash: '0x8a7CE9B****F5dD2841',
    inToken: 'ETH',
    inAmount: '2.5',
    outToken: 'LINK',
    outAmount: 80.67321976,
    age: '12d 14h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '10,213,909',
    hash: '0x2e4CE1D****C6fE4723',
    inToken: 'DAI',
    inAmount: '15',
    outToken: 'USDC',
    outAmount: 14.998763,
    age: '10d 6h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '7,321,504',
    hash: '0x9b3DE7A****D8eB8132',
    inToken: 'BTC',
    inAmount: '0.1',
    outToken: 'ETH',
    outAmount: 2.86542901,
    age: '20d 3h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '12,345,678',
    hash: '0x4c6FA8E****A1bC6405',
    inToken: 'LINK',
    inAmount: '10',
    outToken: 'AAVE',
    outAmount: 5.98765432,
    age: '9d 8h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '13,876,543',
    hash: '0x3b2DE3C****F7dA2819',
    inToken: 'USDC',
    inAmount: '100',
    outToken: 'BTC',
    outAmount: 0.03215678,
    age: '5d 17h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '14,567,890',
    hash: '0x1e9CB4F****B8cD9726',
    inToken: 'AAVE',
    inAmount: '3',
    outToken: 'ETH',
    outAmount: 89.7654321,
    age: '7d 21h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '10,213,909',
    hash: '0x2e4CE1D****C6fE4723',
    inToken: 'DAI',
    inAmount: '15',
    outToken: 'USDC',
    outAmount: 14.998763,
    age: '10d 6h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '7,321,504',
    hash: '0x9b3DE7A****D8eB8132',
    inToken: 'BTC',
    inAmount: '0.1',
    outToken: 'ETH',
    outAmount: 2.86542901,
    age: '20d 3h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '12,345,678',
    hash: '0x4c6FA8E****A1bC6405',
    inToken: 'LINK',
    inAmount: '10',
    outToken: 'AAVE',
    outAmount: 5.98765432,
    age: '9d 8h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '9,512,738',
    hash: '0x8a7CE9B****F5dD2841',
    inToken: 'ETH',
    inAmount: '2.5',
    outToken: 'LINK',
    outAmount: 80.67321976,
    age: '12d 14h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '10,213,909',
    hash: '0x2e4CE1D****C6fE4723',
    inToken: 'DAI',
    inAmount: '15',
    outToken: 'USDC',
    outAmount: 14.998763,
    age: '10d 6h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '7,321,504',
    hash: '0x9b3DE7A****D8eB8132',
    inToken: 'BTC',
    inAmount: '0.1',
    outToken: 'ETH',
    outAmount: 2.86542901,
    age: '20d 3h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '12,345,678',
    hash: '0x4c6FA8E****A1bC6405',
    inToken: 'LINK',
    inAmount: '10',
    outToken: 'AAVE',
    outAmount: 5.98765432,
    age: '9d 8h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '13,876,543',
    hash: '0x3b2DE3C****F7dA2819',
    inToken: 'USDC',
    inAmount: '100',
    outToken: 'BTC',
    outAmount: 0.03215678,
    age: '5d 17h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '14,567,890',
    hash: '0x1e9CB4F****B8cD9726',
    inToken: 'AAVE',
    inAmount: '3',
    outToken: 'ETH',
    outAmount: 89.7654321,
    age: '7d 21h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '11,108,503',
    hash: '0x6f8CE2F****E9af1971',
    inToken: 'BUSD',
    inAmount: '22',
    outToken: 'UNI',
    outAmount: 1.03567263940143,
    age: '18d 9h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '9,512,738',
    hash: '0x8a7CE9B****F5dD2841',
    inToken: 'ETH',
    inAmount: '2.5',
    outToken: 'LINK',
    outAmount: 80.67321976,
    age: '12d 14h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '10,213,909',
    hash: '0x2e4CE1D****C6fE4723',
    inToken: 'DAI',
    inAmount: '15',
    outToken: 'USDC',
    outAmount: 14.998763,
    age: '10d 6h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '7,321,504',
    hash: '0x9b3DE7A****D8eB8132',
    inToken: 'BTC',
    inAmount: '0.1',
    outToken: 'ETH',
    outAmount: 2.86542901,
    age: '20d 3h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '12,345,678',
    hash: '0x4c6FA8E****A1bC6405',
    inToken: 'LINK',
    inAmount: '10',
    outToken: 'AAVE',
    outAmount: 5.98765432,
    age: '9d 8h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '13,876,543',
    hash: '0x3b2DE3C****F7dA2819',
    inToken: 'USDC',
    inAmount: '100',
    outToken: 'BTC',
    outAmount: 0.03215678,
    age: '5d 17h ago'
  },
  {
    account: '0x17d4****f0dD',
    height: '14,567,890',
    hash: '0x1e9CB4F****B8cD9726',
    inToken: 'AAVE',
    inAmount: '3',
    outToken: 'ETH',
    outAmount: 89.7654321,
    age: '7d 21h ago'
  }
];
