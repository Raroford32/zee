import image1 from '../assets/icons/notifications/image 1.png';
import image2 from '../assets/icons/notifications/image 2.png';
import image3 from '../assets/icons/notifications/image 3.png';
import image4 from '../assets/icons/notifications/image 4.png';
import image5 from '../assets/icons/notifications/image 5.png';

export const notifications = [
  {
    img: image1,
    title: 'New PET-ETH Yield Farm on KyberSwap...',
    description: 'Last week KyberSwap launched 2 $PET pools with our frens Hello Pets...',
    time: '4 hours ago'
  },
  {
    img: image2,
    title: 'KyberSwap has released our 2nd NPS...',
    description:
      'Your opinion matters! Share your thoughts to help us improve your experience on KyberSwap...',
    time: '5 hours ago'
  },
  {
    img: image3,
    title: 'zkBOB farms continue on KyberSwap!',
    description:
      'Farm with stMATIC-BOB on Polygon & ETH-BOB on Optimism and earn optimised $KNC & $BOB...',
    time: '7 hours ago'
  },
  {
    img: image4,
    title: 'New USDC-axlUSDC yield farm on...',
    description:
      'Axelar Network launches USDC-axlUSDC yield farm with KyberSwap Elastic on Avalanche...',
    time: '8 hours ago'
  },
  {
    img: image5,
    title: 'KyberSwap Arbitrum NFT Trading...',
    description:
      "Hey Kyberians! Enjoying #ArbSeason so far? Let's take it to the next level with a KyberSwap...",
    time: '9 hours ago'
  },
  {
    img: image3,
    title: 'zkBOB farms continue on KyberSwap!',
    description:
      'Farm with stMATIC-BOB on Polygon & ETH-BOB on Optimism and earn optimised $KNC & $BOB...',
    time: '7 hours ago'
  },
  {
    img: image4,
    title: 'New USDC-axlUSDC yield farm on...',
    description:
      'Axelar Network launches USDC-axlUSDC yield farm with KyberSwap Elastic on Avalanche...',
    time: '8 hours ago'
  },
  {
    img: image5,
    title: 'KyberSwap Arbitrum NFT Trading...',
    description:
      "Hey Kyberians! Enjoying #ArbSeason so far? Let's take it to the next level with a KyberSwap...",
    time: '9 hours ago'
  },
];
