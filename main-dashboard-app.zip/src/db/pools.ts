import BNB from '../assets/icons/cryptocurrenciesIcons/BNB.svg';
import BUSD from '../assets/icons/cryptocurrenciesIcons/BUSD.svg';
import DASH from '../assets/icons/cryptocurrenciesIcons/DASH.svg';
import DOGE from '../assets/icons/cryptocurrenciesIcons/DOGE.svg';
import DOT from '../assets/icons/cryptocurrenciesIcons/DOT.svg';
import FLOKI from '../assets/icons/cryptocurrenciesIcons/FLOKI.svg';
import GEN from '../assets/icons/cryptocurrenciesIcons/GEN.svg';
import LINA from '../assets/icons/cryptocurrenciesIcons/LINA.svg';
import LTC from '../assets/icons/cryptocurrenciesIcons/LTC.svg';
import RVN from '../assets/icons/cryptocurrenciesIcons/RVN.svg';
import USDC from '../assets/icons/cryptocurrenciesIcons/USDC.svg';
import USDT from '../assets/icons/cryptocurrenciesIcons/USDT.svg';
import WOO from '../assets/icons/cryptocurrenciesIcons/WOO.svg';
import XRP from '../assets/icons/cryptocurrenciesIcons/XRP.svg';
import ZRX from '../assets/icons/cryptocurrenciesIcons/ZRX.svg';
import ETH from '../assets/icons/cryptocurrenciesIcons/ETH.svg';

// function generateRandomId() {
//   return Math.floor(Math.random() * 1000000);
// }

export const pools = [
  {
    id: 1,
    fromName: 'BNB',
    fromIcon: BNB,
    toName: 'BUSD',
    toIcon: BUSD,
    type: 'Classic',
    liquidity: 589791648,
    APR: 56.33
  },
  {
    id: 2,
    fromName: 'DASH',
    fromIcon: DASH,
    toName: 'DOGE',
    toIcon: DOGE,
    type: 'Classic',
    liquidity: 456782321,
    APR: 42.15
  },
  {
    id: 3,
    fromName: 'DOT',
    fromIcon: DOT,
    toName: 'FLOKI',
    toIcon: FLOKI,
    type: 'Stable',
    liquidity: 784593276,
    APR: 73.24
  },
  {
    id: 4,
    fromName: 'GEN',
    fromIcon: GEN,
    toName: 'LINA',
    toIcon: LINA,
    type: 'Classic',
    liquidity: 356794512,
    APR: 31.78
  },
  {
    id: 5,
    fromName: 'LTC',
    fromIcon: LTC,
    toName: 'RVN',
    toIcon: RVN,
    type: 'Stable',
    liquidity: 654821390,
    APR: 59.92
  },
  {
    id: 6,
    fromName: 'USDC',
    fromIcon: USDC,
    toName: 'USDT',
    toIcon: USDT,
    type: 'Stable',
    liquidity: 987654321,
    APR: 91.2
  },
  {
    id: 7,
    fromName: 'WOO',
    fromIcon: WOO,
    toName: 'XRP',
    toIcon: XRP,
    type: 'Classic',
    liquidity: 234567890,
    APR: 21.45
  },
  {
    id: 8,
    fromName: 'ZRX',
    fromIcon: ZRX,
    toName: 'ETH',
    toIcon: ETH,
    type: 'Classic',
    liquidity: 765432109,
    APR: 70.89
  },
  {
    id: 9,
    fromName: 'DASH',
    fromIcon: DASH,
    toName: 'DOGE',
    toIcon: DOGE,
    type: 'Classic',
    liquidity: 456782321,
    APR: 42.15
  },
  {
    id: 10,
    fromName: 'DOT',
    fromIcon: DOT,
    toName: 'FLOKI',
    toIcon: FLOKI,
    type: 'Stable',
    liquidity: 784593276,
    APR: 73.24
  },
  {
    id: 11,
    fromName: 'GEN',
    fromIcon: GEN,
    toName: 'LINA',
    toIcon: LINA,
    type: 'Classic',
    liquidity: 356794512,
    APR: 31.78
  },
  {
    id: 12,
    fromName: 'LTC',
    fromIcon: LTC,
    toName: 'RVN',
    toIcon: RVN,
    type: 'Stable',
    liquidity: 654821390,
    APR: 59.92
  },
  {
    id: 13,
    fromName: 'USDC',
    fromIcon: USDC,
    toName: 'USDT',
    toIcon: USDT,
    type: 'Stable',
    liquidity: 987654321,
    APR: 91.2
  },
  {
    id: 14,
    fromName: 'WOO',
    fromIcon: WOO,
    toName: 'XRP',
    toIcon: XRP,
    type: 'Classic',
    liquidity: 234567890,
    APR: 21.45
  },
  {
    id: 15,
    fromName: 'ZRX',
    fromIcon: ZRX,
    toName: 'ETH',
    toIcon: ETH,
    type: 'Classic',
    liquidity: 765432109,
    APR: 70.89
  },
  {
    id: 16,
    fromName: 'DASH',
    fromIcon: DASH,
    toName: 'DOGE',
    toIcon: DOGE,
    type: 'Classic',
    liquidity: 456782321,
    APR: 42.15
  },
  {
    id: 17,
    fromName: 'DOT',
    fromIcon: DOT,
    toName: 'FLOKI',
    toIcon: FLOKI,
    type: 'Stable',
    liquidity: 784593276,
    APR: 73.24
  },
  {
    id: 18,
    fromName: 'GEN',
    fromIcon: GEN,
    toName: 'LINA',
    toIcon: LINA,
    type: 'Classic',
    liquidity: 356794512,
    APR: 31.78
  },
  {
    id: 19,
    fromName: 'LTC',
    fromIcon: LTC,
    toName: 'RVN',
    toIcon: RVN,
    type: 'Stable',
    liquidity: 654821390,
    APR: 59.92
  },
  {
    id: 20,
    fromName: 'USDC',
    fromIcon: USDC,
    toName: 'USDT',
    toIcon: USDT,
    type: 'Stable',
    liquidity: 987654321,
    APR: 91.2
  },
  {
    id: 21,
    fromName: 'WOO',
    fromIcon: WOO,
    toName: 'XRP',
    toIcon: XRP,
    type: 'Classic',
    liquidity: 234567890,
    APR: 21.45
  },
  {
    id: 22,
    fromName: 'ZRX',
    fromIcon: ZRX,
    toName: 'ETH',
    toIcon: ETH,
    type: 'Classic',
    liquidity: 765432109,
    APR: 70.89
  }
];
