import BNB from '../assets/icons/cryptocurrenciesIcons/BNB.svg';
import BUSD from '../assets/icons/cryptocurrenciesIcons/BUSD.svg';
import DASH from '../assets/icons/cryptocurrenciesIcons/DASH.svg';
import DOGE from '../assets/icons/cryptocurrenciesIcons/DOGE.svg';
import DOT from '../assets/icons/cryptocurrenciesIcons/DOT.svg';
import FLOKI from '../assets/icons/cryptocurrenciesIcons/FLOKI.svg';
import GEN from '../assets/icons/cryptocurrenciesIcons/GEN.svg';
import LINA from '../assets/icons/cryptocurrenciesIcons/LINA.svg';
import LTC from '../assets/icons/cryptocurrenciesIcons/LTC.svg';
import RVN from '../assets/icons/cryptocurrenciesIcons/RVN.svg';
import USDC from '../assets/icons/cryptocurrenciesIcons/USDC.svg';
import USDT from '../assets/icons/cryptocurrenciesIcons/USDT.svg';
import WOO from '../assets/icons/cryptocurrenciesIcons/WOO.svg';
import XRP from '../assets/icons/cryptocurrenciesIcons/XRP.svg';
import ZRX from '../assets/icons/cryptocurrenciesIcons/ZRX.svg';

export const tokens = [
  {
    name: 'BNB',
    valueToUSD: 300.0,
    icon: BNB,
    fullName: 'Binance Coin'
  },
  {
    name: 'BUSD',
    valueToUSD: 1.0,
    icon: BUSD,
    fullName: 'Binance USD'
  },
  {
    name: 'DASH',
    valueToUSD: 150.0,
    icon: DASH,
    fullName: 'Dash'
  },
  {
    name: 'DOGE',
    valueToUSD: 0.3,
    icon: DOGE,
    fullName: 'Dogecoin'
  },
  {
    name: 'DOT',
    valueToUSD: 30.0,
    icon: DOT,
    fullName: 'Polkadot'
  },
  {
    name: 'FLOKI',
    valueToUSD: 0.01,
    icon: FLOKI,
    fullName: 'Shiba Inu'
  },
  {
    name: 'GEN',
    valueToUSD: 2.5,
    icon: GEN,
    fullName: 'DAOstack'
  },
  {
    name: 'LINA',
    valueToUSD: 0.2,
    icon: LINA,
    fullName: 'Linear'
  },
  {
    name: 'LTC',
    valueToUSD: 150.0,
    icon: LTC,
    fullName: 'Litecoin'
  },
  {
    name: 'RVN',
    valueToUSD: 0.1,
    icon: RVN,
    fullName: 'Ravencoin'
  },
  {
    name: 'USDC',
    valueToUSD: 1.0,
    icon: USDC,
    fullName: 'USD Coin'
  },
  {
    name: 'USDT',
    valueToUSD: 1.0,
    icon: USDT,
    fullName: 'Tether'
  },
  {
    name: 'WOO',
    valueToUSD: 10.0,
    icon: WOO,
    fullName: 'Wootrade'
  },
  {
    name: 'XRP',
    valueToUSD: 1.5,
    icon: XRP,
    fullName: 'Ripple'
  },
  {
    name: 'ZRX',
    valueToUSD: 0.5,
    icon: ZRX,
    fullName: '0x'
  }
];
