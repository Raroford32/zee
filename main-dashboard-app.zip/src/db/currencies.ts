// import AU from '../assets/icons/currencies/AU.svg';
// import CA from '../assets/icons/currencies/CA.svg';
// import IND from '../assets/icons/currencies/IND.svg';
// import JPN from '../assets/icons/currencies/JPN.svg';
// import PL from '../assets/icons/currencies/PL.svg';
import EUR from '../assets/icons/currencies/EUR.svg';
import GBP from '../assets/icons/currencies/GBP.svg';
import USD from '../assets/icons/currencies/USD.svg';

export const currencies = [
  {
    name: 'USD',
    valueToUSD: 1,
    icon: USD,
    fullName: 'United States Dollar'
  },
  {
    name: 'EUR',
    valueToUSD: 1.18,
    icon: EUR,
    fullName: 'Euro'
  },
  {
    name: 'GBP',
    valueToUSD: 1.38,
    icon: GBP,
    fullName: 'British Pound Sterling'
  },
  // {
  //   name: 'AU',
  //   valueToUSD: 0.73,
  //   icon: AU,
  //   fullName: 'Australian Dollar'
  // },
  // {
  //   name: 'CA',
  //   valueToUSD: 0.78,
  //   icon: CA,
  //   fullName: 'Canadian Dollar'
  // },
  // {
  //   name: 'IND',
  //   valueToUSD: 0.014,
  //   icon: IND,
  //   fullName: 'Indian Rupee'
  // },
  // {
  //   name: 'JPN',
  //   valueToUSD: 0.0091,
  //   icon: JPN,
  //   fullName: 'Japanese Yen'
  // },
  // {
  //   name: 'PL',
  //   valueToUSD: 0.25,
  //   icon: PL,
  //   fullName: 'Polish Zloty'
  // },
];
