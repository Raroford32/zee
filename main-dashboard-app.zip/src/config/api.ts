const showCorrectUrl = true;
const urlCoin = showCorrectUrl ? 'https://api.coingecko.com/api/v3/coins' : 'https://';

export const TrendingCoins = (currency: string = 'usd') =>
  `${urlCoin}/markets?vs_currency=${currency}&order=gecko_desc&per_page=20&page=1&sparkline=false&price_change_percentage=24h`;

export const MarketChart = (id: string, currency: string, days: number) =>
  `${urlCoin}/${id}/market_chart?vs_currency=${currency}&days=${days}&interval=daily`

export const MarketCoins = (ids: string[], currency: string = 'usd') =>
  `${urlCoin}/markets?vs_currency=${currency}&ids=${ids}`;

